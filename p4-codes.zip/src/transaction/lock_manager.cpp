#include "lock_manager.hpp"

#include <memory>
#include <shared_mutex>
#include <iostream>

#include "common/exception.hpp"
#include "common/logging.hpp"
#include "fmt/core.h"
#include "transaction/txn.hpp"
#include "transaction/txn_manager.hpp"

namespace wing {

// For debug
void print_txn_state(Txn* txn) {
  switch (txn->state_)
  {
  case TxnState::ABORTED: {std::cout<<"ABORTED";return;}
  case TxnState::COMMITTED: {std::cout<<"COMMITTED";return;}
  case TxnState::GROWING: {std::cout<<"GROWING";return;}
  case TxnState::SHRINKING: {std::cout<<"SHRINKING";return;}
  }
  return;
}

// For debug
void print_table_lock_size(Txn* txn) {
  std::cout<<"[";
  if (txn->table_lock_set_.count(LockMode::S) != 0) {
    std::cout<<txn->table_lock_set_[LockMode::S].size()<<", ";
  } else {
    std::cout<<0<<", ";
  }
  if (txn->table_lock_set_.count(LockMode::X) != 0) {
    std::cout<<txn->table_lock_set_[LockMode::X].size()<<", ";
  } else {
    std::cout<<0<<", ";
  }
  if (txn->table_lock_set_.count(LockMode::IS) != 0) {
    std::cout<<txn->table_lock_set_[LockMode::IS].size()<<", ";
  } else {
    std::cout<<0<<", ";
  }
  if (txn->table_lock_set_.count(LockMode::IX) != 0) {
    std::cout<<txn->table_lock_set_[LockMode::IX].size()<<", ";
  } else {
    std::cout<<0<<", ";
  }
  if (txn->table_lock_set_.count(LockMode::SIX) != 0) {
    std::cout<<txn->table_lock_set_[LockMode::SIX].size()<<"]";
  } else {
    std::cout<<0<<"]";
  }
}

// For debug
void print_tuple_lock_size(Txn* txn) {
  std::cout<<"[";
  if (txn->tuple_lock_set_.count(LockMode::S) != 0) {
      std::cout<<"{";
      for(auto& table : txn->tuple_lock_set_[LockMode::S]) {
          std::cout<<table.second.size()<<",";
      }
      std::cout<<"}";
  } else {
    std::cout<<0<<", ";
  }
  if (txn->tuple_lock_set_.count(LockMode::X) != 0) {
    std::cout<<"{";
      for(auto& table : txn->tuple_lock_set_[LockMode::X]) {
          std::cout<<table.second.size()<<",";
      }
      std::cout<<"}";
  } else {
    std::cout<<0<<", ";
  }
  if (txn->tuple_lock_set_.count(LockMode::IS) != 0) {
    std::cout<<"{";
      for(auto& table : txn->tuple_lock_set_[LockMode::IS]) {
          std::cout<<table.second.size()<<",";
      }
      std::cout<<"}";
  } else {
    std::cout<<0<<", ";
  }
  if (txn->tuple_lock_set_.count(LockMode::IX) != 0) {
    std::cout<<"{";
      for(auto& table : txn->tuple_lock_set_[LockMode::IX]) {
          std::cout<<table.second.size()<<",";
      }
      std::cout<<"}";
  } else {
    std::cout<<0<<", ";
  }
  if (txn->tuple_lock_set_.count(LockMode::SIX) != 0) {
    std::cout<<"{";
      for(auto& table : txn->tuple_lock_set_[LockMode::SIX]) {
          std::cout<<table.second.size()<<",";
      }
      std::cout<<"}]";
  } else {
    std::cout<<0<<"]";
  }
}

// For debug
void print_mode(LockMode m) {
  switch(m) {
    case LockMode::IS: {std::cout<<"IS"; return;}
    case LockMode::IX: {std::cout<<"IX"; return;}
    case LockMode::SIX: {std::cout<<"SIX"; return;}
    case LockMode::S: {std::cout<<"S"; return;}
    case LockMode::X: {std::cout<<"X"; return;}
  }
  return;
}

// mode_priority(a, b) = true: a >= b in priority
const bool mode_priority(LockMode m1, LockMode m2) {
    switch (m1) {
        case LockMode::IS: {
            switch (m2) {
                case LockMode::IS: return 1;
                case LockMode::IX: return 0;
                case LockMode::SIX: return 0;
                case LockMode::S: return 0;
                case LockMode::X: return 0;
            }
        }
        case LockMode::IX: {
            switch (m2) {
                case LockMode::IS: return 1;
                case LockMode::IX: return 1;
                case LockMode::SIX: return 0;
                case LockMode::S: return 0;
                case LockMode::X: return 0;
            }
        }
        case LockMode::SIX: {
            switch (m2) {
                case LockMode::IS: return 1;
                case LockMode::IX: return 1;
                case LockMode::SIX: return 1;
                case LockMode::S: return 1;
                case LockMode::X: return 0;
            }
        }
        case LockMode::S: {
            switch (m2) {
                case LockMode::IS: return 1;
                case LockMode::IX: return 0;
                case LockMode::SIX: return 0;
                case LockMode::S: return 1;
                case LockMode::X: return 0;
            }
        }
        case LockMode::X: {
            switch (m2) {
                case LockMode::IS: return 1;
                case LockMode::IX: return 1;
                case LockMode::SIX: return 1;
                case LockMode::S: return 1;
                case LockMode::X: return 1;
            }
        }
        default: return 0;
    }
}

// valid_update(a, b) = true: can update from a to b
const bool valid_update(LockMode m1, LockMode m2) {
        switch (m1) {
            case LockMode::IS: {
                switch (m2) {
                    case LockMode::S: return 1;
                    case LockMode::X: return 1;
                    case LockMode::IX: return 1;
                    case LockMode::SIX: return 1;
                    default: return 0;
                }
            }
            case LockMode::S: {
                switch (m2) {
                    case LockMode::X: return 1;
                    case LockMode::SIX: return 1;
                    default: return 0;
                }
            }
            case LockMode::IX: {
                switch (m2) {
                    case LockMode::X: return 1;
                    case LockMode::SIX: return 1;
                    default: return 0;
                }
            }
            case LockMode::SIX: {
                switch (m2) {
                    case LockMode::X: return 1;
                    default: return 0;
                }
            }
            default: return 0;
        }
}

// mode_conflict(a, b) = true: modes a and b conflict
const bool mode_conflict(LockMode m1, LockMode m2) {
    switch (m1) {
        case LockMode::IS: {
            switch (m2) {
                case LockMode::IS: return 0;
                case LockMode::IX: return 0;
                case LockMode::SIX: return 0;
                case LockMode::S: return 0;
                case LockMode::X: return 1;
            }
        }
        case LockMode::IX: {
            switch (m2) {
                case LockMode::IS: return 0;
                case LockMode::IX: return 0;
                case LockMode::SIX: return 1;
                case LockMode::S: return 1;
                case LockMode::X: return 1;
            }
        }
        case LockMode::SIX: {
            switch (m2) {
                case LockMode::IS: return 0;
                case LockMode::IX: return 1;
                case LockMode::SIX: return 1;
                case LockMode::S: return 1;
                case LockMode::X: return 1;
            }
        }
        case LockMode::S: {
            switch (m2) {
                case LockMode::IS: return 0;
                case LockMode::IX: return 1;
                case LockMode::SIX: return 1;
                case LockMode::S: return 0;
                case LockMode::X: return 1;
            }
        }
        case LockMode::X: {
            switch (m2) {
                case LockMode::IS: return 1;
                case LockMode::IX: return 1;
                case LockMode::SIX: return 1;
                case LockMode::S: return 1;
                case LockMode::X: return 1;
            }
        }
        default: return 1;
    }
}

// mode_match(a, b) = true: intention lock a and exclusive lock b matches
const bool mode_match(LockMode m1, LockMode m2) {
        switch (m2) {
            case LockMode::S: {
                return 1;
            }
            case LockMode::X: {
                if (m1 == LockMode::IX || m1 == LockMode::SIX || m1 == LockMode::X ) {
                    return 1;
                } else {
                    return 0;
                }
            }
            default: return 0;
        }
}

// Find whether a txn is in the LockRequestList
// Return the pointer pointing to the target request if exists
std::optional<std::shared_ptr<LockManager::LockRequest>> find_request(std::list<std::shared_ptr<LockManager::LockRequest>>& list, Txn *txn) {
    for (std::shared_ptr<LockManager::LockRequest>& request : list) {
        if (request->txn_id_ == txn->txn_id_) {
            return {request};
        }
    }
    return {};
}


bool has_conflict(std::list<std::shared_ptr<LockManager::LockRequest>>& list, LockMode mode, txn_id_t txn_id) {
    for (std::shared_ptr<LockManager::LockRequest>& request : list) {
        if (request->granted_ && request->txn_id_ != txn_id && mode_conflict(request->mode_, mode)) {
            return true;
        }
    }
    return false;
}

bool wait_die(std::list<std::shared_ptr<LockManager::LockRequest>>& list, LockMode mode, txn_id_t txn_id) {
    for (std::shared_ptr<LockManager::LockRequest>& request : list) {
        if (request->granted_ && request->txn_id_ < txn_id && mode_conflict(request->mode_, mode)) {
            return true;
        }
    }
    return false;
}

void LockManager::AcquireTableLock(
    std::string_view table_name, LockMode mode, Txn *txn) {
  // P4 TODO
  // Check the state of the `txn`
  std::shared_lock<std::shared_mutex> txn_lock(txn->rw_latch_);
  if (txn->state_ == TxnState::ABORTED) {
      throw TxnInvalidBehaviorException("Aborted txn trying to acquire a table lock.");
      return;
  }
  if (txn->state_ == TxnState::SHRINKING) {
      txn->state_ = TxnState::ABORTED;
      throw TxnInvalidBehaviorException("Shrinking txn trying to acquire a table lock.");
      return;
  }
  // Lock the `table_lock_table` to find the LockRequestList `table_lock_request_list`
  table_lock_table_latch_.lock();
  std::string table_name_raw(table_name.data(), table_name.size());
  if (table_lock_table_.count(table_name_raw) == 0) {
      // The first lock on this table, can directly acquire the lock and return
      // Update `table_lock_table_` of lock manager
      std::shared_ptr<LockRequest> new_request = std::make_shared<LockRequest>(txn->txn_id_, mode);
      new_request->granted_ = true;
      LockRequestList* new_lock_request_list = new LockRequestList;
      new_lock_request_list->list_.emplace_back(new_request);
      std::unique_ptr<LockRequestList> new_lock_request_list_ptr(new_lock_request_list);
      table_lock_table_[table_name_raw] = std::move(new_lock_request_list_ptr);
      // Update `table_lock_set_` of the txn
      txn->table_lock_set_[mode].insert(table_name_raw);
      table_lock_table_latch_.unlock();
      return;
  }
  LockRequestList* table_lock_request_list = table_lock_table_[table_name_raw].get();
  // Lock the LockRequestList `table_lock_request_list`
  std::unique_lock<std::mutex> table_lock_request_list_lock(table_lock_request_list->latch_);
  // Find the `table_lock_request` of this `txn` if exists
  std::optional<std::shared_ptr<LockManager::LockRequest>> table_lock_request = find_request(table_lock_request_list->list_, txn);
  table_lock_table_latch_.unlock();
  if (table_lock_request.has_value() && table_lock_request.value()->granted_ && table_lock_request.value()->mode_ == mode) {
      // If the txn already has satisfied lock
      return;
  }
  else {
      // If the txn doesn't have any satisfied lock
      if (!table_lock_request.has_value()) {
          // Either the txn need to append an ungranted new request to the list
          table_lock_request_list->list_.emplace_back(std::make_shared<LockRequest>(txn->txn_id_, mode));
      } else {
          // Or the txn need to update existed request to an ungranted new request
          // Check whether the update is valid
          if (valid_update(table_lock_request.value()->mode_, mode)) {
              // Valid update but conflict update
              if (table_lock_request_list->upgrading_ != INVALID_TXN_ID && table_lock_request_list->upgrading_ != txn->txn_id_) {
                  txn->state_ = TxnState::ABORTED;
                  throw MultiUpgradeException("Multiple upgrade when acquiring a table lock.");
                  return;
              }
              // Valid update
              table_lock_request_list->upgrading_ = txn->txn_id_;
          } else {
              // Invalid update
              txn->state_ = TxnState::ABORTED;
              throw TxnInvalidBehaviorException("Invalid update when acquiring a table lock.");
              return;
          }
      }
      // Try to acquire the lock
      while (true) {
          bool flag = false; // whether the txn need to wait on cv
          // As long as there are conflicts between `mode` and the locks currently held by other txns, `txn`'s request need to wait in the list
          if (has_conflict(table_lock_request_list->list_, mode, txn->txn_id_)) {
              flag = true;
              // Check if deadlock: wait-die
              if (wait_die(table_lock_request_list->list_, mode, txn->txn_id_)) {
                  // Abort the txn
                  txn->state_ = TxnState::ABORTED;
                  // Remove the ungranted request from the list
                  auto iter = table_lock_request_list->list_.begin();
                  while (iter != table_lock_request_list->list_.end() && iter->get()->txn_id_ != txn->txn_id_) {
                      iter++;
                  }
                  if (iter == table_lock_request_list->list_.end()) {
                      DB_ERR("Wait-die error.");
                      return;
                  }
                  if (!iter->get()->granted_) {
                      table_lock_request_list->list_.erase(iter);
                      if (table_lock_request_list->list_.size() == 0) {
                        // Remove the `table_lock_table_[table_name_raw]`
                        table_lock_table_latch_.lock();
                        table_lock_table_.erase(table_name_raw);
                        table_lock_table_latch_.unlock();
                    }
                  }
                  // Remove the updating txn if it is this txn
                  if (table_lock_request_list->upgrading_ == txn->txn_id_) {
                      table_lock_request_list->upgrading_ = INVALID_TXN_ID;
                  }
                  // Throw exception
                  throw TxnDLAbortException("Wait-die abort because of TxnDLAbortException.");
                  return;
              }
          }
          // As long as there exists a txn waiting for upgrading, other txns's request need to wait until the upgrading finishes
          else if (table_lock_request_list->upgrading_ != INVALID_TXN_ID && table_lock_request_list->upgrading_ != txn->txn_id_) {
              flag = true;
          }
          // As long as there exist other txns that has request before `txn` in the LockRequestList, can acquire lock, and conflict `txn` after they acquire the lock, `txn` need to wait
          else if (table_lock_request_list->upgrading_ == INVALID_TXN_ID) {
              for (std::shared_ptr<LockManager::LockRequest>& request : table_lock_request_list->list_) {
                  if (request->txn_id_ == txn->txn_id_) {
                      break;
                  }
                  if (!request->granted_ && !has_conflict(table_lock_request_list->list_, request->mode_, request->txn_id_) &&
                      mode_conflict(request->mode_, mode)) {
                      flag = true;
                      break;
                  }
              }
          }
          // flag == false, no need to wait on cv, directly get the lock
          if (!flag) {break;}
          // flag == true, need to wait on cv
          table_lock_request_list->cv_.wait(table_lock_request_list_lock);
      }
      // Get the lock
      // Update the request and `txn`'s table_lock_set_
      for (std::shared_ptr<LockManager::LockRequest>& request : table_lock_request_list->list_) {
          if (request->txn_id_ == txn->txn_id_) {
              request->granted_ = true;
              break;
          }
      }
      if (table_lock_request_list->upgrading_ == txn->txn_id_) {
          txn->table_lock_set_[table_lock_request.value()->mode_].erase(table_name_raw);
          table_lock_request.value()->mode_ = mode;
          table_lock_request.value()->granted_ = true;
          table_lock_request_list->upgrading_ = INVALID_TXN_ID;
      }
      if (txn->table_lock_set_.count(mode) == 0 || txn->table_lock_set_[mode].count(table_name_raw) == 0) {
          txn->table_lock_set_[mode].insert(table_name_raw);
      }
      // `txn_lock` and `table_lock_request_list_lock` are automatically released
  }
}

void LockManager::ReleaseTableLock(
    std::string_view table_name, LockMode mode, Txn *txn) {
  // P4 TODO
  // Set the `txn`'s new state
  std::shared_lock<std::shared_mutex> txn_lock(txn->rw_latch_);
  if (txn->state_ != TxnState::ABORTED && txn->state_ != TxnState::COMMITTED) {
    txn->state_ = TxnState::SHRINKING;
  }
  // Lock the `table_lock_table_latch` to find the LockRequestList `table_lock_request_list`
  table_lock_table_latch_.lock();
  std::string table_name_raw(table_name.data(), table_name.size());
  if (table_lock_table_.count(table_name_raw) == 0) {
      table_lock_table_latch_.unlock();
      DB_ERR("Table not found.");
      return;
  }
  LockRequestList* table_lock_request_list = table_lock_table_[table_name_raw].get();
  // Lock the `table_lock_request_list`
  // Find and remove the target request from `table_lock_request_list` to release the lock
  table_lock_request_list->latch_.lock();
  auto iter = table_lock_request_list->list_.begin();
  while (iter != table_lock_request_list->list_.end() && iter->get()->txn_id_ != txn->txn_id_) {
      iter++;
  }
  if (iter == table_lock_request_list->list_.end()) {
      table_lock_request_list->latch_.unlock();
      table_lock_table_latch_.unlock();
      DB_ERR("Lock not found in the table lock request list.");
      return;
  }
  table_lock_request_list->list_.erase(iter);
  if (table_lock_request_list->list_.size() == 0) {
      // Remove the `table_lock_table_[table_name_raw]`
      table_lock_table_.erase(table_name_raw);
  }
  table_lock_request_list->latch_.unlock();
  table_lock_table_latch_.unlock();
  // Wake up all waiting txns
  table_lock_request_list->cv_.notify_all();
  // Update the `table_lock_set_` of the txn
  if (txn->table_lock_set_.count(mode) == 0) {
      DB_ERR("Lock not found in the txn's table lock set.");
      return;
  }
  txn->table_lock_set_[mode].erase(table_name_raw);
  if (txn->table_lock_set_[mode].size() == 0) {
      txn->table_lock_set_.erase(mode);
  }
}

void LockManager::AcquireTupleLock(std::string_view table_name,
    std::string_view key, LockMode mode, Txn *txn) {
    // P4 TODO
    // Check whether the lock is intention lock
    if (mode == LockMode::IX || mode == LockMode::IS || mode == LockMode::SIX) {
        txn->state_ = TxnState::ABORTED;
        throw TxnInvalidBehaviorException("Tuple lock is intention lock.");
        return;
    }
    // Check the state of the `txn`
    std::shared_lock<std::shared_mutex> txn_lock(txn->rw_latch_);
    if (txn->state_ == TxnState::ABORTED) {
        throw TxnInvalidBehaviorException("Aborted txn trying to acquire a tuple lock.");
        return;
    }
    if (txn->state_ == TxnState::SHRINKING) {
        txn->state_ = TxnState::ABORTED;
        throw TxnInvalidBehaviorException("Shrinking txn trying to acquire a tuple lock.");
        return;
    }
    // Check whether the txn has already acquired the intention lock
    table_lock_table_latch_.lock();
    std::string table_name_raw(table_name.data(), table_name.size());
    if (table_lock_table_.count(table_name_raw) == 0) {
        txn->state_ = TxnState::ABORTED;
        table_lock_table_latch_.unlock();
        throw TxnInvalidBehaviorException("No intention lock when acquiring tuple lock.");
        return;
    }
    LockRequestList* table_lock_request_list = table_lock_table_[table_name_raw].get(); // find the LockRequestList
    table_lock_request_list->latch_.lock(); // lock the LockRequestList
    std::optional<std::shared_ptr<LockManager::LockRequest>> table_lock_request = find_request(table_lock_request_list->list_, txn); // find the request
    bool has_intention_lock = false;
    if (table_lock_request.has_value() && table_lock_request.value()->granted_ && mode_match(table_lock_request.value()->mode_, mode)) {
        has_intention_lock = true;
    }
    table_lock_request_list->latch_.unlock(); // unlock the LockRequestList
    table_lock_table_latch_.unlock();
    if (!has_intention_lock) {
        txn->state_ = TxnState::ABORTED;
        throw TxnInvalidBehaviorException("No intention lock when acquiring tuple lock.");
        return;
    }
    // Find the `tuple_lock_request` of this `txn` if exists
    tuple_lock_table_latch_.lock();
    std::string key_raw(key.data(), key.size());
    if (tuple_lock_table_.count(table_name_raw) == 0 || tuple_lock_table_[table_name_raw].count(key_raw) == 0) {
        // The first lock on this tuple, can directly acquire the lock and return
        // Update `tuple_lock_table_` of lock manager
        std::shared_ptr<LockRequest> new_request = std::make_shared<LockRequest>(txn->txn_id_, mode);
        new_request->granted_ = true;
        LockRequestList* new_lock_request_list = new LockRequestList;
        new_lock_request_list->list_.emplace_back(new_request);
        std::unique_ptr<LockRequestList> new_lock_request_list_ptr(new_lock_request_list);
        tuple_lock_table_[table_name_raw][key_raw] = std::move(new_lock_request_list_ptr);
        // Update tuple_lock_set_` of the txn
        txn->tuple_lock_set_[mode][table_name_raw].insert(key_raw);
        tuple_lock_table_latch_.unlock();
        return;
    }
    LockRequestList* tuple_lock_request_list = tuple_lock_table_[table_name_raw][key_raw].get();
    // Lock the LockRequestList `tuple_lock_request_list`
    std::unique_lock<std::mutex> tuple_lock_request_list_lock(tuple_lock_request_list->latch_);
    // Find the `tuple_lock_request` of this `txn` if exists
    std::optional<std::shared_ptr<LockManager::LockRequest>> tuple_lock_request = find_request(tuple_lock_request_list->list_, txn);
    tuple_lock_table_latch_.unlock();
    if (tuple_lock_request.has_value() && tuple_lock_request.value()->granted_ && tuple_lock_request.value()->mode_ == mode) {
        // If the txn already has satisfied lock
        return;
    }
    else {
        // If the txn doesn't have any satisfied lock
        if (!tuple_lock_request.has_value()) {
            // Either the txn need to append an ungranted new request to the list
            tuple_lock_request_list->list_.emplace_back(std::make_shared<LockRequest>(txn->txn_id_, mode));
        } else {
            // Or the txn need to update existed request to an ungranted new request
            // Check whether the update is valid
            if (valid_update(tuple_lock_request.value()->mode_, mode)) {
                // Valid update but conflict update
                if (tuple_lock_request_list->upgrading_ != INVALID_TXN_ID && tuple_lock_request_list->upgrading_ != txn->txn_id_) {
                    txn->state_ = TxnState::ABORTED;
                    throw MultiUpgradeException("Multiple upgrade when acquiring a tuple lock.");
                    return;
                }
                // Valid update
                tuple_lock_request_list->upgrading_ = txn->txn_id_;
            } else {
                // Invalid update
                txn->state_ = TxnState::ABORTED;
                throw TxnInvalidBehaviorException("Invalid update when acquiring a tuple lock.");
                return;
            }
        }
        // Try to acquire the lock
        while (true) {
            bool flag = false; // whether the txn need to wait on cv
            // As long as there are conflicts between `mode` and the locks currently held by other txns, `txn`'s request need to wait in the list
            if (has_conflict(tuple_lock_request_list->list_, mode, txn->txn_id_)) {
                flag = true;
                // Check if deadlock: wait-die
                if (wait_die(tuple_lock_request_list->list_, mode, txn->txn_id_)) {
                    // Abort the txn
                    txn->state_ = TxnState::ABORTED;
                    // Remove the ungranted request from the list
                    auto iter = tuple_lock_request_list->list_.begin();
                    while (iter != tuple_lock_request_list->list_.end() && iter->get()->txn_id_ != txn->txn_id_) {
                        iter++;
                    }
                    if (iter == tuple_lock_request_list->list_.end()) {
                        DB_ERR("Wait-die error.");
                        return;
                    }
                    if (!iter->get()->granted_) {
                      tuple_lock_request_list->list_.erase(iter);
                      if (tuple_lock_request_list->list_.size() == 0) {
                        // Remove the `tuple_lock_table_[table_name_raw][key_raw]`
                        tuple_lock_table_latch_.lock();
                        tuple_lock_table_[table_name_raw].erase(key_raw);
                        if (tuple_lock_table_[table_name_raw].size() == 0) {
                            tuple_lock_table_.erase(table_name_raw);
                        }
                        tuple_lock_table_latch_.unlock();
                      }
                    }
                    // Remove the updating txn if it is this txn
                    if (tuple_lock_request_list->upgrading_ == txn->txn_id_) {
                        tuple_lock_request_list->upgrading_ = INVALID_TXN_ID;
                    }
                    // Throw exception
                    throw TxnDLAbortException("Wait-die abort.");
                    return;
                }
            }
            // As long as there exists a txn waiting for upgrading, other txns's request need to wait until the upgrading finishes
            else if (tuple_lock_request_list->upgrading_ != INVALID_TXN_ID && tuple_lock_request_list->upgrading_ != txn->txn_id_) {
                flag = true;
            }
            // As long as there exist other txns that has request before `txn` in the LockRequestList, can acquire lock, and conflict `txn` after they acquire the lock, `txn` need to wait
            else if (tuple_lock_request_list->upgrading_ == INVALID_TXN_ID) {
                for (std::shared_ptr<LockManager::LockRequest>& request : tuple_lock_request_list->list_) {
                    if (request->txn_id_ == txn->txn_id_) {
                        break;
                    }
                    if (!request->granted_ && !has_conflict(tuple_lock_request_list->list_, request->mode_, request->txn_id_) &&
                        mode_conflict(request->mode_, mode)) {
                        flag = true;
                        break;
                    }
                }
            }
            // flag == false, no need to wait on cv, directly get the lock
            if (!flag) {break;}
            // flag == true, need to wait on cv
            tuple_lock_request_list->cv_.wait(tuple_lock_request_list_lock);
        }
        // Get the lock
        // Update the request and `txn`'s tuple_lock_set_
        for (std::shared_ptr<LockManager::LockRequest>& request : tuple_lock_request_list->list_) {
            if (request->txn_id_ == txn->txn_id_) {
                request->granted_ = true;
                break;
            }
        }
        if (tuple_lock_request_list->upgrading_ == txn->txn_id_) {
            txn->tuple_lock_set_[tuple_lock_request.value()->mode_][table_name_raw].erase(key_raw);
            tuple_lock_request.value()->mode_ = mode;
            tuple_lock_request.value()->granted_ = true;
            tuple_lock_request_list->upgrading_ = INVALID_TXN_ID;
        }
        if (txn->tuple_lock_set_.count(mode) == 0 || txn->tuple_lock_set_[mode].count(table_name_raw) == 0 || txn->tuple_lock_set_[mode][table_name_raw].count(key_raw) == 0) {
            txn->tuple_lock_set_[mode][table_name_raw].insert(key_raw);
        }
        // `txn_lock` and `tuple_lock_request_list_lock` are automatically released
    }
}

void LockManager::ReleaseTupleLock(std::string_view table_name,
    std::string_view key, LockMode mode, Txn *txn) {
  // P4 TODO
  // Set the `txn`'s new state
  std::shared_lock<std::shared_mutex> txn_lock(txn->rw_latch_);
  if (txn->state_ != TxnState::ABORTED && txn->state_ != TxnState::COMMITTED) {
    txn->state_ = TxnState::SHRINKING;
  }
  // Lock the `tuple_lock_table_latch` to find the LockRequestList `tuple_lock_request_list`
  tuple_lock_table_latch_.lock();
  std::string table_name_raw(table_name.data(), table_name.size());
  std::string key_raw(key.data(), key.size());
  if (tuple_lock_table_.count(table_name_raw) == 0) {
      tuple_lock_table_latch_.unlock();
      DB_ERR("Table not found.");
      return;
  } else if (tuple_lock_table_[table_name_raw].count(key_raw) == 0) {
      tuple_lock_table_latch_.unlock();
      DB_ERR("Tuple not found.");
      return;
  }
  LockRequestList* tuple_lock_request_list = tuple_lock_table_[table_name_raw][key_raw].get();
  // Lock the `tuple_lock_request_list`
  // Find and remove the target request from `tuple_lock_request_list` to release the lock
  tuple_lock_request_list->latch_.lock();
  auto iter = tuple_lock_request_list->list_.begin();
  while (iter != tuple_lock_request_list->list_.end() && iter->get()->txn_id_ != txn->txn_id_) {
      iter++;
  }
  if (iter == tuple_lock_request_list->list_.end()) {
      tuple_lock_request_list->latch_.unlock();
      tuple_lock_table_latch_.unlock();
      DB_ERR("Lock not found in the tuple lock request list.");
      return;
  }
  tuple_lock_request_list->list_.erase(iter);
  if (tuple_lock_request_list->list_.size() == 0) {
      // Remove the tuple from `tuple_lock_table_`
      tuple_lock_table_[table_name_raw].erase(key_raw);
      if (tuple_lock_table_[table_name_raw].size() == 0) {
          tuple_lock_table_.erase(table_name_raw);
      }
  }
  tuple_lock_request_list->latch_.unlock();
  tuple_lock_table_latch_.unlock();
  // Wake up all waiting txns
  tuple_lock_request_list->cv_.notify_all();
  // Update the `tuple_lock_set_` of the txn
  if (txn->tuple_lock_set_.count(mode) == 0 || txn->tuple_lock_set_[mode].count(table_name_raw) == 0) {
      DB_ERR("Lock not found in the tuple lock set.");
  }
  txn->tuple_lock_set_[mode][table_name_raw].erase(key_raw);
  if (txn->tuple_lock_set_[mode][table_name_raw].size() == 0) {
      txn->tuple_lock_set_[mode].erase(table_name_raw);
  }
  if (txn->tuple_lock_set_[mode].size() == 0) {
      txn->tuple_lock_set_.erase(mode);
  }
}

}  // namespace wing