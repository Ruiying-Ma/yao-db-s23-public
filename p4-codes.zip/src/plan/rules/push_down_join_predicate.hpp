#ifndef SAKURA_PUSHDOWN_JOIN_PREDICATE_H__
#define SAKURA_PUSHDOWN_JOIN_PREDICATE_H__

#include "common/logging.hpp"
#include "plan/expr_utils.hpp"
#include "plan/output_schema.hpp"
#include "plan/rules/rule.hpp"



namespace wing {
    class PushDownJoinPredicateRule : public OptRule {
    public:
        bool Match(const PlanNode* node) override {
            if (node->type_ == PlanType::Join) {
                const JoinPlanNode* t_node = static_cast<const JoinPlanNode*>(node);
                // t_node->ch_ and t_node->ch2_ must be non-null
                left_can_pushdown_ = false;
                right_can_pushdown_ = false;
                for (auto&& a : t_node->predicate_.GetVec()) {
                    // Check whether PredicateElement `a` contains tables in the right join side
                    if ((!a.CheckLeft(t_node->ch2_->table_bitset_)) && (!a.CheckRight(t_node->ch2_->table_bitset_))) {
                        left_can_pushdown_ = true;
                    }
                    // Check whether PredicateElement `a` contains tables in the left join side
                    if ((!a.CheckLeft(t_node->ch_->table_bitset_)) && (!a.CheckRight(t_node->ch_->table_bitset_))) {
                        right_can_pushdown_ = true;
                    }
                }
                return (left_can_pushdown_ || right_can_pushdown_);
            }
            return false;
        }

        std::unique_ptr<PlanNode> Transform(std::unique_ptr<PlanNode> node) override {
            if (node->type_ == PlanType::Join) {
                // Create the new JoinPlanNode `new_node`
                JoinPlanNode* new_node = new JoinPlanNode();
                new_node->output_schema_ = node->output_schema_;
                new_node->table_bitset_ = node->table_bitset_;
                // Create the new FilterPlanNodes `left_filter` and `right_filter` if possible
                FilterPlanNode* left_filter;
                FilterPlanNode* right_filter;
                if (left_can_pushdown_) {
                    left_filter = new FilterPlanNode();
                    left_filter->output_schema_ = node->ch_->output_schema_;
                    left_filter->table_bitset_ = node->ch_->table_bitset_;
                }
                if (right_can_pushdown_) {
                    right_filter = new FilterPlanNode();
                    right_filter->output_schema_ = node->ch2_->output_schema_;
                    right_filter->table_bitset_ = node->ch2_->table_bitset_;
                }
                // Update `new_node`, `left_filter` and `right_filter`'s PredicateVec
                JoinPlanNode* t_node = static_cast<JoinPlanNode*>(node.get());
                for(auto&& a : t_node->predicate_.GetVec()) {
                    if ((!a.CheckLeft(t_node->ch2_->table_bitset_)) && (!a.CheckRight(t_node->ch2_->table_bitset_))) {
                        // `a` can be pushed down to `new_node->ch_`
                        left_filter->predicate_.Append(PredicateElement{std::move(a.expr_), a.left_bits_, a.right_bits_});
                    }
                    else if ((!a.CheckLeft(t_node->ch_->table_bitset_)) && (!a.CheckRight(t_node->ch_->table_bitset_))) {
                        // `a` can be pushed down to ch2_
                        right_filter->predicate_.Append(PredicateElement{std::move(a.expr_), a.left_bits_, a.right_bits_});
                    }
                    else {
                        // `a` should be put back to `new_node`
                        new_node->predicate_.Append(PredicateElement{std::move(a.expr_), a.left_bits_, a.right_bits_});
                    }
                }
                // Update `new_node`, `left_filter` and `right_filter`'s children
                if (left_can_pushdown_) {
                    std::unique_ptr<PlanNode> temp_ch(left_filter);
                    new_node->ch_ = std::move(temp_ch);
                    new_node->ch_->ch_ = std::move(node->ch_);
                } else {
                    new_node->ch_ = std::move(node->ch_);
                }
                if (right_can_pushdown_) {
                    std::unique_ptr<PlanNode> temp_ch(right_filter);
                    new_node->ch2_ = std::move(temp_ch);
                    new_node->ch2_->ch_ = std::move(node->ch2_);
                } else {
                    new_node->ch2_ = std::move(node->ch2_);
                }
                std::unique_ptr<PlanNode> ret(new_node);
                return ret;
            }
            DB_ERR("Invalid node.");
        }

    private:
        bool left_can_pushdown_{false};
        bool right_can_pushdown_{false};
    };
}  // namespace wing

#endif
