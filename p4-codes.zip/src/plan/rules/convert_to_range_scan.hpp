#ifndef SAKURA_CONVERT_TO_RANGE_SCAN_H__
#define SAKURA_CONVERT_TO_RANGE_SCAN_H__

#include "common/logging.hpp"
#include "plan/expr_utils.hpp"
#include "plan/output_schema.hpp"
#include "plan/rules/rule.hpp"
#include "catalog/db.hpp"
#include "type/field.hpp"

namespace wing {

    class ConvertToRangeScanRule : public OptRule {
    public:
        ConvertToRangeScanRule(DB& db): db_(db){};

        bool Match(const PlanNode* node) override {
            if (node->type_ == PlanType::SeqScan) {
                auto t_node = static_cast<const SeqScanPlanNode*>(node);
                // Get the primary key of the scanned table
                std::string_view table_name(t_node->table_name_);
                const TableSchema& table = db_.GetDBSchema()[db_.GetDBSchema().Find(table_name).value()];
                primary_key_ = table.GetPrimaryKeySchema().name_;
                // Check whether there are expressions of the form `primary_key op literal`
                for (auto&& a : t_node->predicate_.GetVec()) {
                    if (a.expr_->ch0_->type_ == ExprType::COLUMN) {
                        const ColumnExpr* col = static_cast<const ColumnExpr*>(a.expr_->ch0_.get());
                        //std::string table_name_str(table_name.data(), table_name.size());
                        if (col->column_name_ == primary_key_) { // && (col->table_name_ == table_name_str)
                            if ((a.expr_->op_ == OpType::EQ ||
                                 a.expr_->op_ == OpType::GT ||
                                 a.expr_->op_ == OpType::LT ||
                                 a.expr_->op_ == OpType::GEQ ||
                                 a.expr_->op_ == OpType::LEQ) &&
                                (a.expr_->ch1_->type_ == ExprType::LITERAL_INTEGER ||
                                 a.expr_->ch1_->type_ == ExprType::LITERAL_FLOAT ||
                                 a.expr_->ch1_->type_ == ExprType::LITERAL_STRING)) {
                                primary_key_type_ = table.GetPrimaryKeySchema().type_;
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }

        std::unique_ptr<PlanNode> Transform(std::unique_ptr<PlanNode> node) override {
            if(node->type_ == PlanType::SeqScan) {
                SeqScanPlanNode* t_node = static_cast<SeqScanPlanNode*>(node.get());
                // Create the new RangScanPlanNode `new_node`
                RangeScanPlanNode* new_node = new RangeScanPlanNode();
                new_node->table_name_ = t_node->table_name_;
                new_node->output_schema_ = t_node->output_schema_;
                new_node->table_bitset_ = t_node->table_bitset_;
                new_node->ch_ = std::move(t_node->ch_);
                // Use range_predicate to udpate `range_l_, range_r_`; put the remaining predicates into `predicate_`
                for(auto&& a : t_node->predicate_.GetVec()) {
                    if (a.expr_->ch0_->type_ == ExprType::COLUMN) {
                        ColumnExpr* col_left = static_cast<ColumnExpr*>(a.expr_->ch0_.get());
                        if (col_left->column_name_ == primary_key_) {
                            // the expression restricts the primary key, so need to update `rang_l_`, `range_r_`
                            switch (a.expr_->op_) {
                                case OpType::EQ: {
                                    if (primary_key_type_ == FieldType::INT32) {
                                        LiteralIntegerExpr* col_right = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                                        int64_t value = col_right->literal_value_;
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateInt(FieldType::INT32, 4, value);
                                            new_node->range_l_.second = true;
                                        }
                                        else if (new_node->range_l_.first.ReadInt() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first.data_.int_data = value;
                                            new_node->range_l_.second = true;
                                        }
                                        else if ((new_node->range_l_.first.ReadInt() == value) && (!new_node->range_l_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_l_.second = true;
                                        }
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateInt(FieldType::INT32, 4, value);
                                            new_node->range_r_.second = true;
                                        }
                                        else if (new_node->range_r_.first.ReadInt() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first.data_.int_data = value;
                                            new_node->range_r_.second = true;
                                        }
                                        else if ((new_node->range_r_.first.ReadInt() == value) && (!new_node->range_r_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_r_.second = true;
                                        }
                                    }
                                    else if (primary_key_type_ == FieldType::INT64) {
                                        LiteralIntegerExpr* col_right = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                                        int64_t value = col_right->literal_value_;
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateInt(FieldType::INT64, 8, value);
                                            new_node->range_l_.second = true;
                                        }
                                        else if (new_node->range_l_.first.ReadInt() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first.data_.int_data = value;
                                            new_node->range_l_.second = true;
                                        }
                                        else if ((new_node->range_l_.first.ReadInt() == value) && (!new_node->range_l_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_l_.second = true;
                                        }
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateInt(FieldType::INT64, 8, value);
                                            new_node->range_r_.second = true;
                                        }
                                        else if (new_node->range_r_.first.ReadInt() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first.data_.int_data = value;
                                            new_node->range_r_.second = true;
                                        }
                                        else if ((new_node->range_r_.first.ReadInt() == value) && (!new_node->range_r_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_r_.second = true;
                                        }
                                    }
                                    else if ((primary_key_type_ == FieldType::FLOAT64)) {
                                        LiteralFloatExpr* col_right = static_cast<LiteralFloatExpr*>(a.expr_->ch1_.get());
                                        double value = col_right->literal_value_;
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateFloat(FieldType::FLOAT64, 8, value);
                                            new_node->range_l_.second = true;
                                        }
                                        else if (new_node->range_l_.first.ReadFloat() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first.data_.double_data = value;
                                            new_node->range_l_.second = true;
                                        }
                                        else if ((new_node->range_l_.first.ReadFloat() == value) && (!new_node->range_l_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_l_.second = true;
                                        }
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateFloat(FieldType::FLOAT64, 8, value);
                                            new_node->range_r_.second = true;
                                        }
                                        else if (new_node->range_r_.first.ReadFloat() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first.data_.double_data = value;
                                            new_node->range_r_.second = true;
                                        }
                                        else if ((new_node->range_r_.first.ReadFloat() == value) && (!new_node->range_r_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_r_.second = true;
                                        }
                                    }
                                    else if ((primary_key_type_ == FieldType::CHAR) || (primary_key_type_ == FieldType::VARCHAR)) {
                                        LiteralStringExpr* col_right = static_cast<LiteralStringExpr*>(a.expr_->ch1_.get());
                                        std::string value = col_right->literal_value_;
                                        std::string_view value_sv(value);
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_l_.second = true;
                                        }
                                        else if (new_node->range_l_.first.ReadString() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_l_.second = true;
                                        }
                                        else if ((new_node->range_l_.first.ReadString() == value) && (!new_node->range_l_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_l_.second = true;
                                        }
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_r_.second = true;
                                        }
                                        else if (new_node->range_r_.first.ReadString() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_r_.second = true;
                                        }
                                        else if ((new_node->range_r_.first.ReadString() == value) && (!new_node->range_r_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_r_.second = true;
                                        }
                                    }
                                    break;
                                }

                                case OpType::LT: {
                                    if (primary_key_type_ == FieldType::INT32) {
                                        LiteralIntegerExpr* col_right = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                                        int64_t value = col_right->literal_value_;
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateInt(FieldType::INT32, 4, value);
                                            new_node->range_r_.second = false;
                                        }
                                        else if (new_node->range_r_.first.ReadInt() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first.data_.int_data = value;
                                            new_node->range_r_.second = false;
                                        }
                                    }
                                    else if (primary_key_type_ == FieldType::INT64) {
                                        LiteralIntegerExpr* col_right = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                                        int64_t value = col_right->literal_value_;
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateInt(FieldType::INT64, 8, value);
                                            new_node->range_r_.second = false;
                                        }
                                        else if (new_node->range_r_.first.ReadInt() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first.data_.int_data = value;
                                            new_node->range_r_.second = false;
                                        }
                                    }
                                    else if (primary_key_type_ == FieldType::FLOAT64) {
                                        LiteralFloatExpr* col_right = static_cast<LiteralFloatExpr*>(a.expr_->ch1_.get());
                                        double value = col_right->literal_value_;
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateFloat(FieldType::FLOAT64, 8, value);
                                            new_node->range_r_.second = false;
                                        }
                                        else if (new_node->range_r_.first.ReadFloat() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first.data_.double_data = value;
                                            new_node->range_r_.second = false;
                                        }
                                    }
                                    else if ((primary_key_type_ == FieldType::CHAR) || (primary_key_type_ == FieldType::VARCHAR)) {
                                        LiteralStringExpr* col_right = static_cast<LiteralStringExpr*>(a.expr_->ch1_.get());
                                        std::string value = col_right->literal_value_;
                                        std::string_view value_sv(value);
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_r_.second = false;
                                        }
                                        else if (new_node->range_r_.first.ReadString() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_r_.second = false;
                                        }
                                    }
                                    break;
                                }

                                case OpType::GT: {
                                    if (primary_key_type_ == FieldType::INT32) {
                                        LiteralIntegerExpr* col_right = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                                        int64_t value = col_right->literal_value_;
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateInt(FieldType::INT32, 4, value);
                                            new_node->range_l_.second = false;
                                        }
                                        else if (new_node->range_l_.first.ReadInt() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first.data_.int_data = value;
                                            new_node->range_l_.second = false;
                                        }
                                    }
                                    else if (primary_key_type_ == FieldType::INT64) {
                                        LiteralIntegerExpr* col_right = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                                        int64_t value = col_right->literal_value_;
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateInt(FieldType::INT64, 8, value);
                                            new_node->range_l_.second = false;
                                        }
                                        else if (new_node->range_l_.first.ReadInt() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first.data_.int_data = value;
                                            new_node->range_l_.second = false;
                                        }
                                    }
                                    else if (primary_key_type_ == FieldType::FLOAT64) {
                                        LiteralFloatExpr* col_right = static_cast<LiteralFloatExpr*>(a.expr_->ch1_.get());
                                        double value = col_right->literal_value_;
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_l_.first = Field::CreateFloat(FieldType::FLOAT64, 8, value);
                                            new_node->range_l_.second = false;
                                        }
                                        else if (new_node->range_l_.first.ReadFloat() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first.data_.double_data = value;
                                            new_node->range_l_.second = false;
                                        }
                                    }
                                    else if ((primary_key_type_ == FieldType::CHAR) || (primary_key_type_ == FieldType::VARCHAR)) {
                                        LiteralStringExpr* col_right = static_cast<LiteralStringExpr*>(a.expr_->ch1_.get());
                                        std::string value = col_right->literal_value_;
                                        std::string_view value_sv(value);
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_l_.second = false;
                                        }
                                        else if (new_node->range_l_.first.ReadString() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_l_.second = false;
                                        }
                                    }
                                    break;
                                }

                                case OpType::LEQ: {
                                    if (primary_key_type_ == FieldType::INT32) {
                                        LiteralIntegerExpr* col_right = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                                        int64_t value = col_right->literal_value_;
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateInt(FieldType::INT32, 4, value);
                                            new_node->range_r_.second = true;
                                        }
                                        else if (new_node->range_r_.first.ReadInt() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first.data_.int_data = value;
                                            new_node->range_r_.second = true;
                                        }
                                        else if ((new_node->range_r_.first.ReadInt() == value) && (!new_node->range_r_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_r_.second = true;
                                        }
                                    }
                                    else if (primary_key_type_ == FieldType::INT64) {
                                        LiteralIntegerExpr* col_right = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                                        int64_t value = col_right->literal_value_;
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateInt(FieldType::INT64, 8, value);
                                            new_node->range_r_.second = true;
                                        }
                                        else if (new_node->range_r_.first.ReadInt() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first.data_.int_data = value;
                                            new_node->range_r_.second = true;
                                        }
                                        else if ((new_node->range_r_.first.ReadInt() == value) && (!new_node->range_r_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_r_.second = true;
                                        }
                                    }
                                    else if ((primary_key_type_ == FieldType::FLOAT64)) {
                                        LiteralFloatExpr* col_right = static_cast<LiteralFloatExpr*>(a.expr_->ch1_.get());
                                        double value = col_right->literal_value_;
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateFloat(FieldType::FLOAT64, 8, value);
                                            new_node->range_r_.second = true;
                                        }
                                        else if (new_node->range_r_.first.ReadFloat() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first.data_.double_data = value;
                                            new_node->range_r_.second = true;
                                        }
                                        else if ((new_node->range_r_.first.ReadFloat() == value) && (!new_node->range_r_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_r_.second = true;
                                        }
                                    }
                                    else if ((primary_key_type_ == FieldType::CHAR) || (primary_key_type_ == FieldType::VARCHAR)) {
                                        LiteralStringExpr* col_right = static_cast<LiteralStringExpr*>(a.expr_->ch1_.get());
                                        std::string value = col_right->literal_value_;
                                        std::string_view value_sv(value);
                                        // Update range_r_
                                        if (new_node->range_r_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_r_`
                                            new_node->range_r_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_r_.second = true;
                                        }
                                        else if (new_node->range_r_.first.ReadString() > value) {
                                            // Update `range_r_` to a tighter bound
                                            new_node->range_r_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_r_.second = true;
                                        }
                                        else if ((new_node->range_r_.first.ReadString() == value) && (!new_node->range_r_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_r_.second = true;
                                        }
                                    }
                                    break;
                                }

                                case OpType::GEQ: {
                                    if (primary_key_type_ == FieldType::INT32) {
                                        LiteralIntegerExpr* col_right = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                                        int64_t value = col_right->literal_value_;
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateInt(FieldType::INT32, 4, value);
                                            new_node->range_l_.second = true;
                                        }
                                        else if (new_node->range_l_.first.ReadInt() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first.data_.int_data = value;
                                            new_node->range_l_.second = true;
                                        }
                                        else if ((new_node->range_l_.first.ReadInt() == value) && (!new_node->range_l_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_l_.second = true;
                                        }
                                    }
                                    else if (primary_key_type_ == FieldType::INT64) {
                                        LiteralIntegerExpr* col_right = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                                        int64_t value = col_right->literal_value_;
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateInt(FieldType::INT64, 8, value);
                                            new_node->range_l_.second = true;
                                        }
                                        else if (new_node->range_l_.first.ReadInt() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first.data_.int_data = value;
                                            new_node->range_l_.second = true;
                                        }
                                        else if ((new_node->range_l_.first.ReadInt() == value) && (!new_node->range_l_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_l_.second = true;
                                        }
                                    }
                                    else if ((primary_key_type_ == FieldType::FLOAT64)) {
                                        LiteralFloatExpr* col_right = static_cast<LiteralFloatExpr*>(a.expr_->ch1_.get());
                                        double value = col_right->literal_value_;
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateFloat(FieldType::FLOAT64, 8, value);
                                            new_node->range_l_.second = true;
                                        }
                                        else if (new_node->range_l_.first.ReadFloat() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first.data_.double_data = value;
                                            new_node->range_l_.second = true;
                                        }
                                        else if ((new_node->range_l_.first.ReadFloat() == value) && (!new_node->range_l_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_l_.second = true;
                                        }
                                    }
                                    else if ((primary_key_type_ == FieldType::CHAR) || (primary_key_type_ == FieldType::VARCHAR)) {
                                        LiteralStringExpr* col_right = static_cast<LiteralStringExpr*>(a.expr_->ch1_.get());
                                        std::string value = col_right->literal_value_;
                                        std::string_view value_sv(value);
                                        // Update range_l_
                                        if (new_node->range_l_.first.type_ == FieldType::EMPTY) {
                                            // The first time to update `range_l_`
                                            new_node->range_l_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_l_.second = true;
                                        }
                                        else if (new_node->range_l_.first.ReadString() < value) {
                                            // Update `range_l_` to a tighter bound
                                            new_node->range_l_.first = Field::CreateString(FieldType::VARCHAR, value_sv);
                                            new_node->range_l_.second = true;
                                        }
                                        else if ((new_node->range_l_.first.ReadString() == value) && (!new_node->range_l_.second)) {
                                            // Update the open interval to a closed one
                                            new_node->range_l_.second = true;
                                        }
                                    }
                                    break;
                                }

                                default: {
                                    // expression `a` does not determine the range of the primary key, hence should be put into the PredicateVec of the `new_node`
                                    new_node->predicate_.Append(PredicateElement{std::move(a.expr_), a.left_bits_, a.right_bits_});
                                    break;
                                }
                            }
                        }
                        else {
                            // expression `a` does not determine the range of the primary key, hence should be put into the PredicateVec of the `new_node`
                            new_node->predicate_.Append(PredicateElement{std::move(a.expr_), a.left_bits_, a.right_bits_});
                        }
                    } else {
                        // expression `a` does not determine the range of the primary key, hence should be put into the PredicateVec of the `new_node`
                        new_node->predicate_.Append(PredicateElement{std::move(a.expr_), a.left_bits_, a.right_bits_});
                    }
                }
            std::unique_ptr<PlanNode> ret(new_node);
                return ret;
            }
            DB_ERR("Invalid node.");
        }

    private:
        DB& db_;
        std::string primary_key_;
        FieldType primary_key_type_;
    };

}  // namespace wing

#endif
