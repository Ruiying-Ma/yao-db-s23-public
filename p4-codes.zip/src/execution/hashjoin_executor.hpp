#ifndef SAKURA_HASHJOIN_EXECUTOR_H__
#define SAKURA_HASHJOIN_EXECUTOR_H__

#include "execution/executor.hpp"
#include "common/murmurhash.hpp"

namespace wing {

class HashJoinExecutor : public Executor {
    public:
        HashJoinExecutor (const OutputSchema& left_input_schema, const OutputSchema& right_input_schema,
                          const std::unique_ptr<Expr>& predicate,
                          const std::vector<std::unique_ptr<Expr>>& left_hash_exprs, const std::vector<std::unique_ptr<Expr>>& right_hash_exprs,
                          std::unique_ptr<Executor> left_ch, std::unique_ptr<Executor> right_ch) :
                left_input_schema_(left_input_schema), right_input_schema_(right_input_schema),
                predicate_(predicate.get(), left_input_schema, right_input_schema),
                build_side_(left_input_schema),
                left_ch_(std::move(left_ch)), right_ch_(std::move(right_ch)){
            for(auto& expr : left_hash_exprs) {
                left_hash_exprs_.emplace_back(ExprFunction(expr.get(), left_input_schema));
                left_hash_types_.emplace_back(expr->ret_type_);
            }
            for(auto& expr: right_hash_exprs) {
                right_hash_exprs_.emplace_back(ExprFunction(expr.get(), right_input_schema));
                right_hash_types_.emplace_back(expr->ret_type_);
            }
        };

        void Init() override {
            left_ch_->Init();
            right_ch_->Init();
            // Build the hash table from the build side
            InputTuplePtr left_ch_ret;
            while((left_ch_ret = left_ch_->Next())) {
                uint8_t* addr = build_side_.Append(left_ch_ret.Data());
                size_t key = 0x114514;
                size_t index = 0;
                for(auto& expr : left_hash_exprs_) {
                    StaticFieldRef temp_key = expr.Evaluate(left_ch_ret);
                    key = get_hash_(temp_key, left_hash_types_[index], key);
                    index++;
                }
                hash_table_.emplace(key, addr);
            }
            probe_tuple_begin_ = true;
            ret_.resize(left_input_schema_.Size() + right_input_schema_.Size());
        }

        InputTuplePtr Next() override {
            if (hash_table_.size() == 0) {return {};}
            // Probe the hash table
            while(true) {
                if (probe_tuple_begin_) {
                    right_ch_ret_ = right_ch_->Next();
                    if (!right_ch_ret_) {return {};}
                    size_t key = 0x114514;
                    size_t index = 0;
                    for(auto& expr : right_hash_exprs_) {
                        StaticFieldRef temp_key = expr.Evaluate(right_ch_ret_);
                        key = get_hash_(temp_key, right_hash_types_[index], key);
                        index++;
                    }
                    bucket_idx_ = hash_table_.bucket(key);
                    if (hash_table_.bucket_size(bucket_idx_) == 0) {
                        continue;
                    }
                    bucket_iter_ = hash_table_.begin(bucket_idx_);
                    probe_tuple_begin_ = false;
                }
                while(bucket_iter_ != hash_table_.end(bucket_idx_)) {
                    InputTuplePtr left_ch_ret(bucket_iter_->second);
                    
                    if (predicate_ && predicate_.Evaluate(left_ch_ret, right_ch_ret_).ReadInt() == 0) {
                        // If this pair of tuples don't match
                        bucket_iter_++;
                    }
                    else {
                        // If this pair of tuples match (or predicate_ is empty): concatenate this pair of tuples and return
                        size_t left_num_cols = left_input_schema_.Size();
                        size_t right_num_cols = right_input_schema_.Size();
                        // Copy left_ch_ret to ret (in bytes)
                        std::memcpy(&ret_[0], bucket_iter_->second, left_num_cols * sizeof(StaticFieldRef));
                        // Copy right_ch_ret to ret
                        if (right_input_schema_.IsRaw()) {
                            Tuple::DeSerialize((&ret_[0]) + left_num_cols, right_ch_ret_.Data(), right_input_schema_.GetCols());
                        } else {
                            std::memcpy((&ret_[0]) + left_num_cols, right_ch_ret_.Data(), right_num_cols * sizeof(StaticFieldRef));
                        }
                        bucket_iter_++;
                        if (bucket_iter_ == hash_table_.end(bucket_idx_)) {probe_tuple_begin_ = true;}
                        return ret_;
                    }
                    
                }
                if (bucket_iter_ == hash_table_.end(bucket_idx_)) {probe_tuple_begin_ = true;}
            }
        }

    private:
        OutputSchema left_input_schema_, right_input_schema_;
        JoinExprFunction predicate_;
        std::vector<ExprFunction> left_hash_exprs_, right_hash_exprs_;
        std::vector<RetType> left_hash_types_, right_hash_types_;
        TupleVector build_side_;
        std::unique_ptr<Executor> left_ch_, right_ch_;
        std::unordered_multimap<size_t, uint8_t*> hash_table_;
        InputTuplePtr right_ch_ret_;
        size_t bucket_idx_;
        std::unordered_multimap<size_t, uint8_t*>::local_iterator bucket_iter_;
        bool probe_tuple_begin_;
        std::vector<StaticFieldRef> ret_;

        size_t get_hash_(StaticFieldRef& data_, RetType type_, size_t seed_) {
            if (type_ == RetType::STRING) {
                return utils::Hash(StaticFieldRef::GetView(&data_, FieldType::VARCHAR, 0), seed_);
            } else {
                // type_ = RetType::INT || RetType::FLOAT
                return utils::Hash(StaticFieldRef::GetView(&data_, FieldType::INT64, sizeof(int64_t)), seed_);
            }
        }
    };

}  // namespace wing

#endif