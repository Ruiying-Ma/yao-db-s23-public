#include "catalog/stat.hpp"

#include "common/murmurhash.hpp"

namespace wing {

void CountMinSketch::AddCount(std::string_view key, double value) {
  //DB_ERR("Not implemented!");
  for (size_t j = 0; j < funcs_; j++) {
      size_t i = (utils::Hash(key, seeds_[j])) % buckets_;
      data_[i * funcs_ + j] += value;
  }
}

double CountMinSketch::GetFreqCount(std::string_view key) const {
  //DB_ERR("Not implemented!");
  double freq = data_[(utils::Hash(key, seeds_[0]) % buckets_) * funcs_ + 0];
  for (size_t j = 1; j < funcs_; j++) {
      size_t i = (utils::Hash(key, seeds_[j])) % buckets_;
      double cur_freq = data_[i * funcs_ + j];
      freq = (freq <= cur_freq) ? freq : cur_freq;
  }
    return freq;
}

void HyperLL::Add(std::string_view key) {
    //DB_ERR("Not implemented!");
    size_t hash_value = utils::Hash(key, seed_);
    size_t tot_bits = sizeof(size_t) * 8;
    size_t bucket_idx = (hash_value >> (tot_bits - N_));
    size_t remain_value = ((hash_value << N_) >> N_);
    size_t mask = (((size_t)1) << (tot_bits - N_ - 1));
    size_t zero_bits_num = 0;
    while (((remain_value & mask) == 0) && (mask != 0)) {
        zero_bits_num++;
        mask >>= 1;
    }
    // zero_bits_num + 1 is the position (start from 1) of the leftmost 1
    data_[bucket_idx] = (data_[bucket_idx] >= (zero_bits_num + 1)) ? data_[bucket_idx] : (zero_bits_num + 1);
}

double HyperLL::GetDistinctCounts() const {
    //DB_ERR("Not implemented!");
    double alpha;
    size_t reg_count = data_.size();
    if (reg_count <= 16) {
        alpha = 0.673;
    } else if (reg_count <= 32) {
        alpha = 0.697;
    } else if (reg_count <= 64) {
        alpha = 0.709;
    } else {
        alpha = 0.7213 / (1 + 1.079 / reg_count);
    }
    double harmonic_mean_inverse = 0.0;
    for (size_t i = 0; i < reg_count; i++) {
      harmonic_mean_inverse += ((double)1) / (double)(((size_t)1) << (data_[i]));
    }
    return ((alpha * (double)reg_count * (double)reg_count / harmonic_mean_inverse ));
}

}  // namespace wing