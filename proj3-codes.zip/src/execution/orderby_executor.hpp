#ifndef SAKURA_ORDERBY_EXECUTOR_H__
#define SAKURA_ORDERBY_EXECUTOR_H__

#include "execution/executor.hpp"
#include <algorithm>

namespace wing {

    class OrderByExecutor : public Executor {
    public:
        OrderByExecutor(const std::vector<std::pair<RetType, bool>>& order_by_exprs,
                        const size_t& offset,
                        std::unique_ptr<Executor> ch,
                        const OutputSchema& input_schema):
                order_by_exprs_(order_by_exprs),
                offset_(offset),
                ch_(std::move(ch)),
                tuples_(input_schema){};

        void Init() override {
            ch_->Init();
            // Read all tuples and store them in `tuples_`
            InputTuplePtr ch_ret_;
            while((ch_ret_ = ch_->Next())) {
                tuple_ptrs_.emplace_back(tuples_.Append(ch_ret_.Data()));
            }
            // Since OrderBy must be executed after some Project Executor, these returned tuples `ch_ret_` are all in StaticFieldRef form
            // Sort these tuples based on `order_by_exprs` on first `offset` cols
            std::sort(tuple_ptrs_.begin(), tuple_ptrs_.end(),
                      [&](uint8_t* a, uint8_t* b) -> bool {
                          const StaticFieldRef* x = reinterpret_cast<const StaticFieldRef*>(a);
                          const StaticFieldRef* y = reinterpret_cast<const StaticFieldRef*>(b);
                          for(size_t i=0; i < offset_; i++) {
                              switch (order_by_exprs_[i].first) {
                                  case RetType::INT: {
                                      if (x->ReadInt() != y->ReadInt()) {return (order_by_exprs_[i].second ^ (x->ReadInt() > y->ReadInt()));}
                                      x++; y++;
                                      break;
                                  }
                                  case RetType::FLOAT: {
                                      if (x->ReadFloat() != y->ReadFloat()) {return (order_by_exprs_[i].second ^ (x->ReadFloat() > y->ReadFloat()));}
                                      x++; y++;
                                      break;
                                  }
                                  default: { //RetType::STRING
                                      if (x->ReadString() != y->ReadString()) {return (order_by_exprs_[i].second ^ (x->ReadString() > y->ReadString()));}
                                      x++; y++;
                                      break;
                                  }
                              }
                          }
                          return false;
                      });

            iter_ = tuple_ptrs_.begin();
        }

        InputTuplePtr Next() override {
            if (iter_ != tuple_ptrs_.end()) {
                InputTuplePtr ret(*iter_ + offset_ * sizeof(StaticFieldRef));
                iter_++;
                return ret;
            } else {
                return {};
            }
        }

    private:
        std::vector<std::pair<RetType, bool>> order_by_exprs_; // (ret_type, is_asc)
        size_t offset_; // offset_ == order_by_exprs_.size()
        std::unique_ptr<Executor> ch_;
        TupleVector tuples_;
        std::vector<uint8_t*> tuple_ptrs_;
        std::vector<uint8_t*>::const_iterator iter_;
    };

}  // namespace wing

#endif