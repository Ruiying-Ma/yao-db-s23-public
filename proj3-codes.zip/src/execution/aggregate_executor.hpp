#ifndef SAKURA_AGGREGATE_EXECUTOR_H__
#define SAKURA_AGGREGATE_EXECUTOR_H__

#include "execution/executor.hpp"
#include "common/murmurhash.hpp"

namespace wing {

    class AggregateExecutor : public Executor {
    public:
        AggregateExecutor (const std::vector<std::unique_ptr<Expr>>& group_by_exprs,
                           const std::unique_ptr<Expr>& predicate,
                           const std::vector<std::unique_ptr<Expr>>& output_exprs,
                           const OutputSchema& input_schema,
                           std::unique_ptr<Executor> ch) :
                predicate_(predicate.get(), input_schema),
                ch_(std::move(ch)),
                input_schema_(input_schema),
                stored_params_(input_schema){
            for(auto& expr : group_by_exprs) {
                group_by_exprs_.push_back(ExprFunction(expr.get(), input_schema));
                group_by_exprs_type_.push_back(expr->ret_type_);
            }
            for(auto& expr : output_exprs) {
                output_exprs_.push_back(AggregateExprFunction(expr.get(), input_schema));
            }
            output_exprs_agg_intermediate_data_.resize(output_exprs.size());
            group_id_ = 0;
            ret_.resize(output_exprs.size());
        };

        void Init() override {
            ch_->Init();
            InputTuplePtr ch_ret;
            size_t free_id = 0; // group_id to-be-used
            while((ch_ret = ch_->Next())) {
                // Divide tuples into groups according to `group_by_exprs`(hash)
                size_t key = 0x114514;
                size_t index = 0;
                for(auto& expr : group_by_exprs_) {
                    StaticFieldRef temp_key = expr.Evaluate(ch_ret);
                    key = get_hash_(temp_key, group_by_exprs_type_[index], key);
                    index++;
                }
                // If there is no GROUP BY clause, then all tuples form a single group
                if (groups_.count(key)) {
                    // the group already existed
                    size_t group_id = groups_[key];
                    // Calculate the aggregations of this group `group_id` (using `Aggregate`)
                    if (predicate_) {
                        predicate_.Aggregate(group_predicate_agg_intermediate_data_[group_id].get(), ch_ret);
                    }
                    for(size_t i = 0; i < output_exprs_.size(); i++) {
                        output_exprs_[i].Aggregate(output_exprs_agg_intermediate_data_[i][group_id].get(), ch_ret);
                    }
                } else {
                    // the group doesn't exist, need to create a new one
                    size_t group_id = free_id;
                    free_id ++;
                    groups_.emplace(key, group_id);
                    if (predicate_) {
                        //std::unique_ptr<AggregateIntermediateData[]> new_group_predicate_agg_intermediate_data_(new AggregateIntermediateData[predicate_.GetImmediateDataSize()]);
                        //group_predicate_agg_intermediate_data_.push_back(std::move(new_group_predicate_agg_intermediate_data_));
                        group_predicate_agg_intermediate_data_.emplace_back(new AggregateIntermediateData[predicate_.GetImmediateDataSize()]); // vector::push_back is `copy` inside, so we need to transfer the ownership of unique_ptr by using std::move
                    }
                    for(size_t i = 0; i < output_exprs_.size(); i++) {
                        //std::unique_ptr<AggregateIntermediateData[]> new_output_exprs_agg_intermediate_data_(new AggregateIntermediateData[output_exprs_[i].GetImmediateDataSize()]);
                        //output_exprs_agg_intermediate_data_[i].push_back(std::move(new_output_exprs_agg_intermediate_data));
                        output_exprs_agg_intermediate_data_[i].emplace_back(new AggregateIntermediateData[output_exprs_[i].GetImmediateDataSize()]);
                    }
                    stored_params_.Append(ch_ret.Data());
                    // Calculate the aggregations of this group `group_id` (using `FirstEvaluate`)
                    if (predicate_) {
                        predicate_.FirstEvaluate(group_predicate_agg_intermediate_data_[group_id].get(), ch_ret);
                    }
                    for(size_t i = 0; i < output_exprs_.size(); i++) {
                        output_exprs_[i].FirstEvaluate(output_exprs_agg_intermediate_data_[i][group_id].get(), ch_ret);
                    }
                }
            }
        }

        InputTuplePtr Next() override {
            while (true) {
                if (group_id_ >= groups_.size()) {
                    return {};
                }
                InputTuplePtr stored_params_tuple(stored_params_.GetPointerVec()[group_id_]);
                // Check whether current group `group_id_` statisfies the group predicate
                if (predicate_ && predicate_.LastEvaluate(group_predicate_agg_intermediate_data_[group_id_].get(), stored_params_tuple).ReadInt() == 0) {
                    // Not a valid group, discard
                    group_id_ ++;
                    continue;
                }
                // A valid group, output
                for (size_t i = 0; i < output_exprs_.size(); i++) {
                    ret_[i] = output_exprs_[i].LastEvaluate(output_exprs_agg_intermediate_data_[i][group_id_].get(), stored_params_tuple);
                }
                group_id_ ++;
                return ret_;
            }
        }

    private:
        std::vector<ExprFunction> group_by_exprs_;
        std::vector<RetType> group_by_exprs_type_;
        AggregateExprFunction predicate_;
        std::vector<AggregateExprFunction> output_exprs_;
        std::unique_ptr<Executor> ch_;
        std::unordered_map<size_t, size_t> groups_; // (key, group_idx)
        std::vector<std::unique_ptr<AggregateIntermediateData []>> group_predicate_agg_intermediate_data_;
        std::vector<std::vector<std::unique_ptr<AggregateIntermediateData []>>> output_exprs_agg_intermediate_data_;
        size_t group_id_ = 0;
        std::vector<StaticFieldRef> ret_;
        OutputSchema input_schema_;
        TupleStore stored_params_;
        std::unique_ptr<StaticFieldRef[]> raw_data_trans_;

        size_t get_hash_(StaticFieldRef& data_, RetType type_, size_t seed_) {
            if (type_ == RetType::STRING) {
                return utils::Hash(StaticFieldRef::GetView(&data_, FieldType::VARCHAR, 0), seed_);
            } else {
                // type_ = RetType::INT || RetType::FLOAT
                return utils::Hash(StaticFieldRef::GetView(&data_, FieldType::INT64, sizeof(int64_t)), seed_);
            }
        }
    };

}  // namespace wing

#endif