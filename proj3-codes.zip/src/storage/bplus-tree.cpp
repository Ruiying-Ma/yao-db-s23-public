#include "bplus-tree.hpp"

namespace wing {

InnerSlot InnerSlotParse(std::string_view slot) {
	//DB_ERR("Not implemented yet!");
	InnerSlot inner_slot = {
		*(pgid_t *)(slot.data()),
        slot.substr(sizeof(pgid_t)) // `next` is of type pgid_t, which is 4-byte
	};
	return inner_slot;
}
void InnerSlotSerialize(char *s, InnerSlot slot) {
	//DB_ERR("Not implemented yet!");
	pgid_t *serialized_next = (pgid_t *)s;
	*serialized_next = slot.next;
	char *serialized_key = (char *)(serialized_next + 1);
	memcpy(serialized_key, slot.strict_upper_bound.data(), slot.strict_upper_bound.size());
}

LeafSlot LeafSlotParse(std::string_view data) {
	//DB_ERR("Not implemented yet!");
	pgoff_t len_key = *(pgoff_t *)(data.data());
    std::string_view key(data.data() + sizeof(pgoff_t), len_key); // `len_key` is of type pgoff_t, which is 2-byte
	std::string_view value(data.data() + sizeof(pgoff_t) + len_key, data.size()-2-len_key);
	LeafSlot leaf_slot = {key, value};
	return leaf_slot;
}
void LeafSlotSerialize(char *s, LeafSlot slot) {
	//DB_ERR("Not implemented yet!");
	// len_key
	pgoff_t *serialized_len_key = (pgoff_t *)s;
	*serialized_len_key = (pgoff_t)(slot.key.size());

	char *serialized_key = (char *)(serialized_len_key + 1);
	memcpy(serialized_key, slot.key.data(), slot.key.size());

	char* serialized_value = serialized_key + slot.key.size();
	memcpy(serialized_value, slot.value.data(), slot.value.size());
}

}
