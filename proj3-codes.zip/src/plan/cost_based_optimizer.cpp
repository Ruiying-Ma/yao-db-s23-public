#include <queue>

#include "plan/optimizer.hpp"
#include "rules/convert_to_hash_join.hpp"
#include "plan/card_est.hpp"
#include "plan/cost_model.hpp"

namespace wing {

std::unique_ptr<PlanNode> Apply(std::unique_ptr<PlanNode> plan,
    const std::vector<std::unique_ptr<OptRule>>& rules, const DB& db) {
  for (auto& a : rules) {
    if (a->Match(plan.get())) {
      plan = a->Transform(std::move(plan));
      break;
    }
  }
  if (plan->ch2_ != nullptr) {
    plan->ch_ = Apply(std::move(plan->ch_), rules, db);
    plan->ch2_ = Apply(std::move(plan->ch2_), rules, db);
  } else if (plan->ch_ != nullptr) {
    plan->ch_ = Apply(std::move(plan->ch_), rules, db);
  }
  return plan;
}

size_t GetTableNum(const PlanNode* plan) {
  /* We don't want to consider values clause in cost based optimizer. */
  if (plan->type_ == PlanType::Print) {
    return 10000;
  }
  
  if (plan->type_ == PlanType::SeqScan || plan->type_ == PlanType::RangeScan) {
    return 1;
  }

  size_t ret = 0;
  if (plan->ch2_ != nullptr) {
    ret += GetTableNum(plan->ch_.get());
    ret += GetTableNum(plan->ch2_.get());
  } else if (plan->ch_ != nullptr) {
    ret += GetTableNum(plan->ch_.get());
  }
  return ret;
}

bool CheckIsAllJoin(const PlanNode* plan) {
  if (plan->type_ == PlanType::Print || plan->type_ == PlanType::SeqScan || plan->type_ == PlanType::RangeScan) {
    return true;
  }
  if (plan->type_ != PlanType::Join) {
    return false;
  }
  return CheckIsAllJoin(plan->ch_.get()) && CheckIsAllJoin(plan->ch2_.get());
}

bool CheckHasStat(const PlanNode* plan, const DB& db) {
  if (plan->type_ == PlanType::Print) {
    return false;
  }
  if (plan->type_ == PlanType::SeqScan) {
    auto stat = db.GetTableStat(static_cast<const SeqScanPlanNode*>(plan)->table_name_);
    return stat != nullptr;
  }
  if (plan->type_ == PlanType::RangeScan) {
    auto stat = db.GetTableStat(static_cast<const RangeScanPlanNode*>(plan)->table_name_);
    return stat != nullptr;
  }
  if (plan->type_ != PlanType::Join) {
    return false;
  }
  return CheckHasStat(plan->ch_.get(), db) && CheckHasStat(plan->ch2_.get(), db);
}

/** 
 * Check whether we can use cost based optimizer. 
 * For simplicity, we only use cost based optimizer when:
 * (1) The root plan node is Project or Aggregate, and there is only one Project.
 * (2) The other plan nodes can only be Join or SeqScan or RangeScan.
 * (3) The number of tables is <= 10. 
 * (4) All tables have statistics.
*/
bool CheckCondition(const PlanNode* plan, const DB& db) {
  if (GetTableNum(plan) > 10) return false;
  if (plan->type_ != PlanType::Project && plan->type_ != PlanType::Aggregate) return false;
  if (!CheckIsAllJoin(plan->ch_.get())) return false;
  return CheckHasStat(plan->ch_.get(), db);
}

// Each possible set of tables has an OptRecord
class OptRecord {
public:
    uint32_t H_; // the smaller subset of tables
    double F_; // the optimal cost of the subset
    CardEstimator::Summary summary_;
};

// Traverse the parse tree `plan` to collect all predicates
void CollectPredicates(const PlanNode* plan, PredicateVec& predicates) {
    if (plan->type_ == PlanType::SeqScan) {
        const SeqScanPlanNode* t_node = static_cast<const SeqScanPlanNode*>(plan);
        predicates.Append(t_node->predicate_); // Use copy instead of move
    }
    else if (plan->type_ == PlanType::RangeScan) {
        // Although RangeScanPlanNode has `range_l_` and `range_r_`, we omit them here (When we finally generate the new parse tree, we will add them back)
        const RangeScanPlanNode* t_node = static_cast<const RangeScanPlanNode*>(plan);
        predicates.Append(t_node->predicate_);
    }
    else if (plan->type_ == PlanType::Project || plan->type_ == PlanType::Aggregate) {
        CollectPredicates(plan->ch_.get(), predicates);
    }
    else if (plan->type_ == PlanType::Join) {
        const JoinPlanNode* t_node = static_cast<const JoinPlanNode*>(plan);
        predicates.Append(t_node->predicate_);
        CollectPredicates(plan->ch_.get(), predicates);
        CollectPredicates(plan->ch2_.get(), predicates);
    }
    else {
        DB_ERR("Invalid Plan.");
    }
}

// Traverse the parse tree `plan` to initialize all items of `dp_[1]`
void InitDP(PlanNode* plan, std::map<uint32_t, OptRecord>& dp1, std::vector<PlanNode*>& map_s_plan_node, PredicateVec& predicates, DB& db) {
    if (plan->type_ == PlanType::Project || plan->type_ == PlanType::Aggregate) {
        InitDP(plan->ch_.get(), dp1, map_s_plan_node, predicates, db);
    }
    else if (plan->type_ == PlanType::Join) {
        InitDP(plan->ch_.get(), dp1, map_s_plan_node, predicates, db);
        InitDP(plan->ch2_.get(), dp1, map_s_plan_node, predicates, db);
    }
    else if (plan->type_ == PlanType::SeqScan) {
        SeqScanPlanNode* t_node = static_cast<SeqScanPlanNode*>(plan);
        map_s_plan_node.push_back(t_node);
        OptRecord opt_record;
        opt_record.summary_ = CardEstimator::EstimateTable(t_node->table_name_, predicates, plan->output_schema_, db);
        opt_record.F_ = (double)db.GetTableStat(t_node->table_name_)->GetTupleNum(); // the cost of seqscan = tuple_num
        opt_record.H_ = (1 << (map_s_plan_node.size()-1));
        dp1.emplace(opt_record.H_, opt_record);
    }
    else if (plan->type_ == PlanType::RangeScan) {
        // May never enter this case
        RangeScanPlanNode* t_node = static_cast<RangeScanPlanNode*>(plan);
        map_s_plan_node.push_back(t_node);
        OptRecord opt_record;
        opt_record.summary_ = CardEstimator::EstimateTable(t_node->table_name_, predicates, plan->output_schema_, db);
        opt_record.F_ = (double)db.GetTableStat(t_node->table_name_)->GetTupleNum(); // the cost of seqscan = tuple_num
        opt_record.H_ = (1 << (map_s_plan_node.size()-1));
        dp1.emplace(opt_record.H_, opt_record);
    }
    else {
        DB_ERR("Invalid Plan.");
    }
}

// Calculate the cost of joining two disjoint set of tables `l` and `r`
double CalcJoin(CardEstimator::Summary& l, CardEstimator::Summary& r, PredicateVec& predicates) {
    double l_cost = l.size_;
    double r_cost = r.size_;
    if (l_cost == 0 || r_cost == 0) {
        return 0;
    }
    for(auto& expr : predicates.GetVec()) {
        if (expr.expr_->op_ == OpType::EQ && expr.expr_->ch0_->type_ == ExprType::COLUMN && expr.expr_->ch1_->type_ == ExprType::COLUMN) {
            // `expr` is of the form `A.a = B.b`
            ColumnExpr* left_col = static_cast<ColumnExpr*>(expr.expr_->ch0_.get());
            ColumnExpr* right_col = static_cast<ColumnExpr*>(expr.expr_->ch1_.get());
            uint32_t left_col_unique_id = left_col->id_in_column_name_table_;
            uint32_t right_col_unique_id = right_col->id_in_column_name_table_;
            if ((l.distinct_counts_.count(left_col_unique_id) != 0 && r.distinct_counts_.count(right_col_unique_id) != 0) ||
                    (r.distinct_counts_.count(left_col_unique_id) != 0 && l.distinct_counts_.count(right_col_unique_id) != 0)) {
                // Can use hash join, so need to use HashJoinCost
                double cost = CostCalculator::HashJoinCost(l_cost, r_cost);
                double cost_reverse = CostCalculator::HashJoinCost(r_cost, l_cost);
                return ((cost <= cost_reverse) ? cost : cost_reverse);
            }
        }
    }
    return CostCalculator::NestloopJoinCost(l_cost, r_cost);
}

// Use DFS to find the optimal of `S`
// `h` is the current subset of `S` (we require that `h` has at least half of the tables of `S`)
// `r` is the number of bits of `S` that can be selected (from lsb to rsb)
// `m` is the number of 1s of current `h`
// `n` is the numebr of 1s of `S`
// r, m, n <= N_ <= 10
void FindOptimal(uint32_t S, uint32_t h, uint8_t r, uint8_t m, uint8_t n, std::vector<std::map<uint32_t, OptRecord>>& dp, PredicateVec& predicates) {
    if (m < ((n + 1) / 2)) {return;} // `h` cannot have at least half of the tables fo `S`
    if (r == 0 && m == n) {return;} // we find `h` = S` at last, which is not allowed
    if (r == 0) {
        // We find `h` satisfying (n+1)/2 <= m < n
        // We check whether `h` can optimize dp_[n][S]
        CardEstimator::Summary big_subset_summary = dp[m].at(h).summary_;
        CardEstimator::Summary small_subset_summary = dp[n-m].at(S ^ h).summary_;
        double delta = CalcJoin(big_subset_summary, small_subset_summary, predicates);
        if (!dp[n].count(S)) {
            // If we calculate `S` for the first time
            OptRecord S_opt_record;
            // Always record `H_` to be the smaller side
            S_opt_record.H_ = ((big_subset_summary.size_  <= small_subset_summary.size_) ? h : (S ^ h));
            S_opt_record.F_ = dp[m].at(h).F_ + dp[n-m].at(S ^ h).F_ + delta;
            S_opt_record.summary_ = CardEstimator::EstimateJoinEq(predicates, big_subset_summary, small_subset_summary);
            dp[n].emplace(S, S_opt_record);
        } else {
            // Update `S` if necessary
            double new_cost = dp[m].at(h).F_ + dp[n-m].at(S ^ h).F_ + delta;
            if (dp[n].at(S).F_ > new_cost) {
                dp[n][S].H_ = ((big_subset_summary.size_ <= small_subset_summary.size_) ? h : (S ^ h));
                dp[n][S].F_ = new_cost;
                dp[n][S].summary_ = CardEstimator::EstimateJoinEq(predicates, big_subset_summary, small_subset_summary);
            }
        }
        return;
    }
    // Find the leftmost position of 1 of the remaining `r` bits part of `h`
    int k = r-1;
    uint32_t mask = ((uint32_t)1) << k;
    while ((k >= 0) && ((h & mask)== 0)) {
        mask >>= 1;
        k--;
    }
    if (k < 0) {
        // there is no remaining 1 in the remaining parts of `h`
        FindOptimal(S, h, 0, m, n, dp, predicates);
        return;
    } 
    // Recursion
    FindOptimal(S, h, k, m, n, dp, predicates);
    FindOptimal(S, h ^ (((uint32_t)1) << k), k, m-1, n, dp, predicates);
}

// Use DFS to update all items of `dp_[n]`
// `n` is the number of 1s in `S`'s bits
// `m` is the number of bits of `S` that can be revised (from lsb to msb)
// `r` is the number of 1s in the remaining `m` bits of `S`
// n, r, m, <= N_ <= 10
// `N` = N_
void FindSubset(uint8_t n, uint32_t S, uint8_t r, uint8_t m, uint8_t N, std::vector<std::map<uint32_t, OptRecord>>& dp, PredicateVec& predicates) {
    if (m < r) {return;} // the remaining `m` bits cannot accommodate `r` 1s
    if (m == r) {
        // The remaining `m` bits are all-1
        S += (((uint32_t )1) << m) - 1;
        FindOptimal(S, S, N, n, n, dp, predicates);
        return;
    }
    // m > r >= 0
    FindSubset(n, S, r, m-1, N, dp, predicates);
    if (r > 0) {
        FindSubset(n, S | (((uint32_t)1) << (m-1)), r-1, m-1, N, dp, predicates);
    }
}

// Generate the plan according to `dp`
// `S` is the subset of tables
// `n` is the number of 1s in `S`
// `N` is the number of tables in the db
std::unique_ptr<PlanNode> GenPlan(uint32_t S, uint8_t n, uint8_t N,std::vector<PlanNode*>& map_s_plan_node, std::vector<std::map<uint32_t, OptRecord>>& dp) {
    if (n == 1) {
        // Find the position of the unique `1` in `S`
        uint8_t k = 0;
        uint32_t mask = (uint32_t)1;
        while ((S & mask) == 0 ) {
            k++;
            mask <<= 1;
        }
        // Update the SeqScanPlanNode / RangeScanPlanNode
        if (map_s_plan_node[k]->type_ == PlanType::SeqScan) {
            // Should generate `SeqScanPlanNode`
            auto ret = std::make_unique<SeqScanPlanNode>();
            SeqScanPlanNode* t_node = static_cast<SeqScanPlanNode*>(map_s_plan_node[k]);
            ret->output_schema_ = t_node->output_schema_;
            ret->table_bitset_ = t_node->table_bitset_;
            ret->table_name_ = t_node->table_name_;
            // Do not generate predicate (put all predicates in the highest join node)
            return ret;
        }
        else if (map_s_plan_node[k]->type_ == PlanType::RangeScan) {
            // Should generate `RangeScanPlanNode`
            auto ret = std::make_unique<RangeScanPlanNode>();
            RangeScanPlanNode* t_node = static_cast<RangeScanPlanNode*>(map_s_plan_node[k]);
            ret->output_schema_ = t_node->output_schema_;
            ret->table_bitset_ = t_node->table_bitset_;
            ret->table_name_ = t_node->table_name_;
            ret->range_l_ = t_node->range_l_;
            ret->range_r_ = t_node->range_r_;
            // Do not generate predicate (put all predicates in the highest join node)
            return ret;
        }
        DB_ERR("Invalid Plan.");
    }
    // Should generate `JoinPlanNode`
    auto ret = std::make_unique<JoinPlanNode>();
    uint32_t H_S = dp[n].at(S).H_;
    // Count the number of bit-1 in `H_S`
    uint8_t h_n = 0;
    uint32_t mask = (uint32_t)1;
    for(uint8_t i = 0; i < N; i++) {
        if ((H_S & mask) != 0) {
            h_n++;
        }
        mask <<= 1;
    }
    ret->ch_ = GenPlan(H_S, h_n, N, map_s_plan_node, dp);
    ret->ch2_ = GenPlan(S ^ H_S, n - h_n, N, map_s_plan_node, dp);
    ret->output_schema_ = OutputSchema::Concat(ret->ch_->output_schema_, ret->ch2_->output_schema_);
    ret->output_schema_.SetRaw(false);
    ret->table_bitset_ = ret->ch_->table_bitset_ | ret->ch2_->table_bitset_;
    // Do not generate predicate
    return ret;
}


std::unique_ptr<PlanNode> CostBasedOptimizer::Optimize(std::unique_ptr<PlanNode> plan, DB& db) {
  if (CheckCondition(plan.get(), db)) {
    //std::vector<std::unique_ptr<OptRule>> R;
    //R.push_back(std::make_unique<ConvertToHashJoinRule>()); // should be applied after reconstructing the plan
    //plan = Apply(std::move(plan), R, db);
    // TODO...
    // Number of tables in this plan
    size_t N_ = GetTableNum(plan.get());
    // All predicates in this plan
    PredicateVec predicates_;
    // The correspondence between `S` (with only one 1) and the corresponding tables' SeqScanPlanNode. `S` has `N_` bits.
    // We must ensure that these SeqScanPlanNodes are not modified before we finish generating the new plan
    std::vector<PlanNode*> map_s_plan_node_;
    // Each possible set of tables `S` (containing `n` tables) corresponds to an item `(S, OptRecord(S))` in `dp_[n]`
    // `dp_[n]` has (N_, n) `OptRecord`s
    // The total number of items in dp_ is 2^{N_} <= 1024. Hence dp_ takes KB memory. Will not cause stack overflow
    std::vector<std::map<uint32_t, OptRecord>> dp_(N_ + 1);
    // Traverse the parser tree `plan` to collect all predicates into `predicates`
    CollectPredicates(plan.get(), predicates_);
    // Traverse the parser tree `plan` to initialize all items in vector `dp_[1]` by `EstimateTable`
    InitDP(plan.get(), dp_[1], map_s_plan_node_, predicates_, db);
    DB_ASSERT(map_s_plan_node_.size() == N_);
    // Use DFS to update all items in vector `dp_[n]`
    for(uint8_t n = 2; n <= N_; n++) {
        FindSubset(n, 0, n, N_, N_, dp_, predicates_);
    }
    // Generate the new parse tree by retracing from `dp_[N_]`
    // There are at least 2 PlanNodes in the parse tree (root is Project/Aggregate PlanNode, and there must exist SeqScan/RangeScan PlanNode)
    // Hence the highest non-root node must be JoinPlanNode
    std::unique_ptr<PlanNode> highest_join = GenPlan((((uint32_t)1) << N_) - 1, N_, N_, map_s_plan_node_, dp_);
    // Add all predicates to this JoinPlanNode
    JoinPlanNode* t_highest_join = static_cast<JoinPlanNode*>(highest_join.get());
    t_highest_join->predicate_.Append(predicates_);
    // Redirect the root ProjectPlanNode/AggregatePlanNode to `highest_join`
    plan->ch_ = std::move(highest_join);
  }
  // Apply logical optimizations to the (new) plan
  plan = LogicalOptimizer::Optimize(std::move(plan), db);
  // Turn all Join into HashJoin
  std::vector<std::unique_ptr<OptRule>> R;
  R.push_back(std::make_unique<ConvertToHashJoinRule>());
  plan = Apply(std::move(plan), R, db);
  return plan;
}

}  // namespace wing
