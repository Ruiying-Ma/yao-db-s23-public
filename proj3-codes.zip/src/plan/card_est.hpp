#ifndef SAKURA_CARD_EST_H__
#define SAKURA_CARD_EST_H__

#include <string>
#include "catalog/db.hpp"
#include "plan/plan_expr.hpp"
#include "plan/output_schema.hpp"

namespace wing {

class CardEstimator {
 public:
  
  // Necessary data for a group of tables. 
  class Summary {
    public:
      double size_{0}; // estimated # of tuples in the group of joint tables
      std::map<uint32_t, double> distinct_counts_; // estimated (distinct count / # tuples) for each column in the group of tables
  };

  // Use DB statistics to estimate the size of the output of seq scan.
  // We assume that columns are uniformly distributed and independent.
  // You should consider predicates which contain two operands and one is a constant.
  // There are some cases:
  // (1) A.a = 1; 1 = A.a; Use CountMinSketch.
  // (2) A.a > 1; 1 > A.a; or A.a <= 1; Use the maximum element and the minimum element of the table.
  // (3) You should ignore other predicates, such as A.a * 2 + A.b < 1000 and A.a < A.b.
  // (4) 1 > 2; Return 0. You can ignore it, because it should be filtered before optimization.
  // You should check the type of each column and write codes for each case, unfortunately.
  static Summary EstimateTable(std::string_view table_name, const PredicateVec& predicates, const OutputSchema& schema, DB& db) {
    Summary ret;
    // TODO
    // Get the statistics of `table_name`
    const TableStatistics* table_stats = db.GetTableStat(table_name);
    // Get the correspondence between outputschema and storageschema
    /*
    std::optional<uint32_t> index = db.GetDBSchema().Find(table_name);
    if (!index.has_value()) {
        throw DBException("Analyze error: table \'{}\' doesn't exist.", table_name);
    }
    const TableSchema& table = db.GetDBSchema()[index.value()];
    const std::vector<uint32_t>& shuffle_to_storage = table.GetShuffleToStorage();
    */
    // Ensure that `schema` is the same as the output schema of `select * from A`
    // DB_ASSERT(schema.Size() == table_stats->GetDistinctRate().size());
    // Record the one-to-one correspondence between unique_col_id and temp_col_id (temp_col_id is that of storage schema)
    std::map<uint32_t, uint32_t> map_col_id; // (unique_col_id, temp_col_id)
    // Update Summary `ret`;
    double tuple_num = (double)(table_stats->GetTupleNum());
    ret.size_ = tuple_num;
    for (uint32_t i = 0; i < schema.Size(); i++) {
        uint32_t unique_col_id = schema.GetCols()[i].id_; // use output schema to find the unique_col_id
        map_col_id.emplace(unique_col_id, i); // record the correspondence between the unique_col_id and the temp_col_id (in storage)
        ret.distinct_counts_.emplace(unique_col_id, table_stats->GetDistinctRate(i) * tuple_num);
    }
    for (auto& a : predicates.GetVec()) {
        if (a.expr_->op_ == OpType::EQ){
            // `A.col = value`
            if (a.expr_->ch0_->type_ == ExprType::COLUMN && a.expr_->ch1_->type_ != ExprType::COLUMN){
                ColumnExpr* col_expr = static_cast<ColumnExpr*>(a.expr_->ch0_.get());
                uint32_t unique_col_id = col_expr->id_in_column_name_table_;
                if (map_col_id.count(unique_col_id) != 0) {
                    // If `A.col` is in this table, update the table's summary
                    uint32_t temp_col_id = map_col_id[unique_col_id];
                    switch (a.expr_->ch1_->type_) {
                        case ExprType::LITERAL_INTEGER: {
                            LiteralIntegerExpr* const_expr = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                            StaticFieldRef value = StaticFieldRef::CreateInt(const_expr->literal_value_);
                            //std::string_view value_sv(reinterpret_cast<const char*>(&(const_expr->literal_value_)), 8); // the address of `const_expr->literal_value_` is valid as long as `predicates` is valid
                            ret.size_ *= table_stats->GetCountMinSketch(temp_col_id).GetFreqCount(StaticFieldRef::GetView(&value, FieldType::INT32, 4)) / tuple_num;
                            ret.distinct_counts_[unique_col_id] = (ret.size_ > 1) ? 1 : ret.size_; 
                            break;
                        }
                        case ExprType::LITERAL_FLOAT: {
                            LiteralFloatExpr* const_expr = static_cast<LiteralFloatExpr*>(a.expr_->ch1_.get());
                            StaticFieldRef value = StaticFieldRef::CreateFloat(const_expr->literal_value_);
                            //std::string_view value_sv(reinterpret_cast<const char*>(&(const_expr->literal_value_)), 8); // the address of `const_expr->literal_value_` is valid as long as `predicates` is valid
                            ret.size_ *= table_stats->GetCountMinSketch(temp_col_id).GetFreqCount(StaticFieldRef::GetView(&value, FieldType::FLOAT64, 8)) / tuple_num;
                            ret.distinct_counts_[unique_col_id] = (ret.size_ > 1) ? 1 : ret.size_; 
                            break;
                        }
                        case ExprType::LITERAL_STRING: {
                            LiteralStringExpr* const_expr = static_cast<LiteralStringExpr*>(a.expr_->ch1_.get());
                            std::string_view value_sv(const_expr->literal_value_);
                            ret.size_ *= table_stats->GetCountMinSketch(temp_col_id).GetFreqCount(value_sv) / tuple_num;
                            ret.distinct_counts_[unique_col_id] = (ret.size_ > 1) ? 1 : ret.size_; 
                            break;
                        }   
                        default: {break;}
                    }
                }
            }
            // `value = A.col`
            else if (a.expr_->ch1_->type_ == ExprType::COLUMN && a.expr_->ch0_->type_ != ExprType::COLUMN){
                ColumnExpr* col_expr = static_cast<ColumnExpr*>(a.expr_->ch1_.get());
                uint32_t unique_col_id = col_expr->id_in_column_name_table_;
                if (map_col_id.count(unique_col_id) != 0) {
                    // If `A.col` is in this table, update the table's summary
                    uint32_t temp_col_id = map_col_id[unique_col_id];
                    switch (a.expr_->ch0_->type_) {
                        case ExprType::LITERAL_INTEGER: {
                            LiteralIntegerExpr* const_expr = static_cast<LiteralIntegerExpr*>(a.expr_->ch0_.get());
                            StaticFieldRef value = StaticFieldRef::CreateInt(const_expr->literal_value_);
                            //std::string_view value_sv(reinterpret_cast<const char*>(&(const_expr->literal_value_)), 8); // the address of `const_expr->literal_value_` is valid as long as `predicates` is valid
                            ret.size_ *= table_stats->GetCountMinSketch(temp_col_id).GetFreqCount(StaticFieldRef::GetView(&value, FieldType::INT32, 4)) / tuple_num;
                            ret.distinct_counts_[unique_col_id] = (ret.size_ > 1) ? 1 : ret.size_; 
                            break;
                        }
                        case ExprType::LITERAL_FLOAT: {
                            LiteralFloatExpr* const_expr = static_cast<LiteralFloatExpr*>(a.expr_->ch0_.get());
                            StaticFieldRef value = StaticFieldRef::CreateFloat(const_expr->literal_value_);
                            //std::string_view value_sv(reinterpret_cast<const char*>(&(const_expr->literal_value_)), 8); // the address of `const_expr->literal_value_` is valid as long as `predicates` is valid
                            ret.size_ *= table_stats->GetCountMinSketch(temp_col_id).GetFreqCount(StaticFieldRef::GetView(&value, FieldType::FLOAT64, 8)) / tuple_num;
                            ret.distinct_counts_[unique_col_id] = (ret.size_ > 1) ? 1 : ret.size_; 
                            break;
                        }
                        case ExprType::LITERAL_STRING: {
                            LiteralStringExpr* const_expr = static_cast<LiteralStringExpr*>(a.expr_->ch0_.get());
                            std::string_view value_sv(const_expr->literal_value_); 
                            ret.size_ *= table_stats->GetCountMinSketch(temp_col_id).GetFreqCount(value_sv) / tuple_num;
                            ret.distinct_counts_[unique_col_id] = (ret.size_ > 1) ? 1 : ret.size_; 
                            break;
                        }
                        default: {break;}
                    }
                }
            }
        }
        else if (a.expr_->op_ == OpType::GT || a.expr_->op_ == OpType::GEQ) {
            // `A. col > value` or `A.col >= value`
            if (a.expr_->ch0_->type_ == ExprType::COLUMN){
                ColumnExpr* col_expr = static_cast<ColumnExpr*>(a.expr_->ch0_.get());
                uint32_t unique_col_id = col_expr->id_in_column_name_table_;
                if (map_col_id.count(unique_col_id) != 0) {
                    uint32_t temp_col_id = map_col_id[unique_col_id];
                    switch (a.expr_->ch1_->type_) {
                        case ExprType::LITERAL_INTEGER: {
                            double old_size = ret.size_;
                            LiteralIntegerExpr* const_expr = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                            double value = (double)const_expr->literal_value_;
                            double max = (double)(table_stats->GetMax(temp_col_id).ReadInt());
                            double min = (double)(table_stats->GetMin(temp_col_id).ReadInt());
                            if (value <= max){
                                value = ((value >= min) ? value : min);
                                ret.size_ *= (max - value + 1) / (max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        case ExprType::LITERAL_FLOAT: {
                            double old_size = ret.size_;
                            LiteralFloatExpr* const_expr = static_cast<LiteralFloatExpr*>(a.expr_->ch1_.get());
                            double value = const_expr->literal_value_;
                            double max = table_stats->GetMax(temp_col_id).ReadFloat();
                            double min = table_stats->GetMin(temp_col_id).ReadFloat();
                            if (value <= max){
                                value = ((value >= min) ? value : min);
                                ret.size_ *= (max - value + 1) / (max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        case ExprType::LITERAL_STRING: {
                            double old_size = ret.size_;
                            LiteralStringExpr* const_expr = static_cast<LiteralStringExpr*>(a.expr_->ch1_.get());
                            // Use the first symbol of the string to estimate the ratio (may be false, but ignore this)
                            uint8_t value = (uint8_t) const_expr->literal_value_[0];
                            uint8_t max = (uint8_t) table_stats->GetMax(temp_col_id).ReadString()[0];
                            uint8_t min = (uint8_t) table_stats->GetMin(temp_col_id).ReadString()[0];
                            if (value <= max){
                                value = ((value >= min) ? value : min);
                                ret.size_ *= (double)(max - value + 1) / (double)(max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        default: {break;}
                    }
                }
            }
            // `value > A.col` or `value >= A.col`
            else if (a.expr_->ch1_->type_ == ExprType::COLUMN){
                ColumnExpr* col_expr = static_cast<ColumnExpr*>(a.expr_->ch1_.get());
                uint32_t unique_col_id = col_expr->id_in_column_name_table_;
                if (map_col_id.count(unique_col_id) != 0) {
                    uint32_t temp_col_id = map_col_id[unique_col_id];
                    switch (a.expr_->ch0_->type_) {
                        case ExprType::LITERAL_INTEGER: {
                            double old_size = ret.size_;
                            LiteralIntegerExpr* const_expr = static_cast<LiteralIntegerExpr*>(a.expr_->ch0_.get());
                            double value = (double)const_expr->literal_value_;
                            double max = (double)(table_stats->GetMax(temp_col_id).ReadInt());
                            double min = (double)(table_stats->GetMin(temp_col_id).ReadInt());
                            if (min <= value){
                                value = ((value <= max) ? value : max);
                                ret.size_ *= (value - min + 1) / (max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        case ExprType::LITERAL_FLOAT: {
                            double old_size = ret.size_;
                            LiteralFloatExpr* const_expr = static_cast<LiteralFloatExpr*>(a.expr_->ch0_.get());
                            double value = const_expr->literal_value_;
                            double max = table_stats->GetMax(temp_col_id).ReadFloat();
                            double min = table_stats->GetMin(temp_col_id).ReadFloat();
                            if (min <= value){
                                value = ((value <= max) ? value : max);
                                ret.size_ *= (value - min + 1) / (max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        case ExprType::LITERAL_STRING: {
                            double old_size = ret.size_;
                            LiteralStringExpr* const_expr = static_cast<LiteralStringExpr*>(a.expr_->ch0_.get());
                            // Use the first symbol of the string to estimate the ratio (may be false, but ignore this)
                            uint8_t value = (uint8_t)const_expr->literal_value_[0];
                            uint8_t max = (uint8_t)table_stats->GetMax(temp_col_id).ReadString()[0];
                            uint8_t min = (uint8_t)table_stats->GetMin(temp_col_id).ReadString()[0];
                            if (min <= value){
                                value = ((value <= max) ? value : max);
                                ret.size_ *= (double)(value - min + 1) / (double)(max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        default: {break;}
                    }
                }
            }
        }
        else if (a.expr_->op_ == OpType::LT || a.expr_->op_ == OpType::LEQ) {
            // `A.col < value` or `A.col <= value`
            if (a.expr_->ch0_->type_ == ExprType::COLUMN){
                ColumnExpr* col_expr = static_cast<ColumnExpr*>(a.expr_->ch0_.get());
                uint32_t unique_col_id = col_expr->id_in_column_name_table_;
                if (map_col_id.count(unique_col_id) != 0) {
                    uint32_t temp_col_id = map_col_id[unique_col_id];
                    switch (a.expr_->ch1_->type_) {
                        case ExprType::LITERAL_INTEGER: {
                            double old_size = ret.size_;
                            LiteralIntegerExpr* const_expr = static_cast<LiteralIntegerExpr*>(a.expr_->ch1_.get());
                            double value = (double)const_expr->literal_value_;
                            double max = (double)(table_stats->GetMax(temp_col_id).ReadInt());
                            double min = (double)(table_stats->GetMin(temp_col_id).ReadInt());
                            if (min <= value){
                                value = ((value <= max) ? value : max);
                                ret.size_ *= (value - min + 1) / (max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        case ExprType::LITERAL_FLOAT: {
                            double old_size = ret.size_;
                            LiteralFloatExpr* const_expr = static_cast<LiteralFloatExpr*>(a.expr_->ch1_.get());
                            double value = const_expr->literal_value_;
                            double max = table_stats->GetMax(temp_col_id).ReadFloat();
                            double min = table_stats->GetMin(temp_col_id).ReadFloat();
                            if (min <= value){
                                value = ((value <= max) ? value : max);
                                ret.size_ *= (value - min + 1) / (max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        case ExprType::LITERAL_STRING: {
                            double old_size = ret.size_;
                            LiteralStringExpr* const_expr = static_cast<LiteralStringExpr*>(a.expr_->ch1_.get());
                            // Use the first symbol of the string to estimate the ratio (may be false, but ignore this)
                            uint8_t value = (uint8_t)const_expr->literal_value_[0];
                            uint8_t max = (uint8_t)table_stats->GetMax(temp_col_id).ReadString()[0];
                            uint8_t min = (uint8_t)table_stats->GetMin(temp_col_id).ReadString()[0];
                            if (min <= value){
                                value = ((value <= max) ? value : max);
                                ret.size_ *= (double)(value - min + 1) / (double)(max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        default: {break;}
                    }
                }
            }
            // `value < A.col` or `value <= A.col`
            else if (a.expr_->ch1_->type_ == ExprType::COLUMN){
                ColumnExpr* col_expr = static_cast<ColumnExpr*>(a.expr_->ch1_.get());
                uint32_t unique_col_id = col_expr->id_in_column_name_table_;
                if (map_col_id.count(unique_col_id) != 0) {
                    uint32_t temp_col_id = map_col_id[unique_col_id];
                    switch (a.expr_->ch0_->type_) {
                        case ExprType::LITERAL_INTEGER: {
                            double old_size = ret.size_;
                            LiteralIntegerExpr* const_expr = static_cast<LiteralIntegerExpr*>(a.expr_->ch0_.get());
                            double value = (double)const_expr->literal_value_;
                            double max = (double)(table_stats->GetMax(temp_col_id).ReadInt());
                            double min = (double)(table_stats->GetMin(temp_col_id).ReadInt());
                            if (value <= max){
                                value = ((value >= min) ? value : min);
                                ret.size_ *= (max- value + 1) / (max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        case ExprType::LITERAL_FLOAT: {
                            double old_size = ret.size_;
                            LiteralFloatExpr* const_expr = static_cast<LiteralFloatExpr*>(a.expr_->ch0_.get());
                            double value = const_expr->literal_value_;
                            double max = table_stats->GetMax(temp_col_id).ReadFloat();
                            double min = table_stats->GetMin(temp_col_id).ReadFloat();
                            if (value <= max){
                                value = ((value >= min) ? value : min);
                                ret.size_ *= (max- value + 1) / (max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        case ExprType::LITERAL_STRING: {
                            double old_size = ret.size_;
                            LiteralStringExpr* const_expr = static_cast<LiteralStringExpr*>(a.expr_->ch0_.get());
                            // Use the first symbol of the string to estimate the ratio (may be false, but ignore this)
                            uint8_t value = (uint8_t)const_expr->literal_value_[0];
                            uint8_t max = (uint8_t)table_stats->GetMax(temp_col_id).ReadString()[0];
                            uint8_t min = (uint8_t)table_stats->GetMin(temp_col_id).ReadString()[0];
                            if (value <= max){
                                value = ((value >= min) ? value : min);
                                ret.size_ *= (double)(max- value + 1) / (double)(max - min + 1);
                            } else {
                                ret.size_ = 0;
                            }
                            // No need to update `ret.distinct_rate_[unique_col_id]` under uniform assumption
                            ret.distinct_counts_[unique_col_id] *= ret.size_ / old_size;
                            break;
                        }
                        default: {break;}
                    }
                }
            }
        }
    }
    return ret;
  }

  // Only consider about equality predicates such as 'A.a = B.b'
  // For other join predicates, you should ignore them.
  // There is no difference of choosing which one to be the build side
  static Summary EstimateJoinEq(const PredicateVec& predicates, const Summary& build, const Summary& probe) {
    Summary ret;
    // TODO
    if (build.size_ == 0 || probe.size_ == 0) {
        ret.size_ = 0;
        return ret;
    }
    ret.size_ = build.size_ * probe.size_;
    // ret.distinct_rate_ is the union of that of the build side and the probe side
    ret.distinct_counts_ = build.distinct_counts_;
    for(auto& a : probe.distinct_counts_) {
        ret.distinct_counts_.emplace(a.first, a.second);
    }
    for(auto& expr : predicates.GetVec()){
        // Update `ret` if there exists expression `A.a = B.b`
        if (expr.expr_->op_ == OpType::EQ && expr.expr_->ch0_->type_ == ExprType::COLUMN && expr.expr_->ch1_->type_ == ExprType::COLUMN) {
            ColumnExpr* left_col = static_cast<ColumnExpr*>(expr.expr_->ch0_.get());
            ColumnExpr* right_col = static_cast<ColumnExpr*>(expr.expr_->ch1_.get());
            uint32_t left_col_unique_id = left_col->id_in_column_name_table_;
            uint32_t right_col_unique_id = right_col->id_in_column_name_table_;
            // When call this function, it is ensured that the columns that `build` and `probe` cover are disjoint
            if (build.distinct_counts_.count(left_col_unique_id) != 0 && probe.distinct_counts_.count(right_col_unique_id) != 0) {
                // `A.a` is in build side; `B.b` is in probe side
                double left_col_distinct_counts = build.distinct_counts_.at(left_col_unique_id);
                double right_col_distinct_counts = probe.distinct_counts_.at(right_col_unique_id);
                //double left_col_distinct_count = left_col_distinct_rate * build.size_;
                //double right_col_distinct_count = right_col_distinct_rate * probe.size_;
                if (left_col_distinct_counts <= right_col_distinct_counts) {
                    ret.size_ /= right_col_distinct_counts;
                    ret.distinct_counts_[right_col_unique_id] = left_col_distinct_counts;
                } else {
                    ret.size_ /= left_col_distinct_counts;
                    ret.distinct_counts_[left_col_unique_id] = right_col_distinct_counts;
                }
            }
            else if (build.distinct_counts_.count(right_col_unique_id) != 0 && probe.distinct_counts_.count(left_col_unique_id) != 0) {
                // `B.b` is in build side; `A.a` is in probe side
                double right_col_distinct_counts = build.distinct_counts_.at(right_col_unique_id);
                double left_col_distinct_counts = probe.distinct_counts_.at(left_col_unique_id);
                //double right_col_distinct_count = right_col_distinct_rate * build.size_;
                //double left_col_distinct_count = left_col_distinct_rate * probe.size_;
                if (left_col_distinct_counts <= right_col_distinct_counts) {
                    ret.size_ /= right_col_distinct_counts;
                    ret.distinct_counts_[right_col_unique_id] = left_col_distinct_counts;
                } else {
                    ret.size_ /= left_col_distinct_counts;
                    ret.distinct_counts_[left_col_unique_id] = right_col_distinct_counts;
                }
            }

        }
    }
    return ret;
  }
};

}

#endif