#ifndef SAKURA_DISTINCT_EXECUTOR_H__
#define SAKURA_DISTINCT_EXECUTOR_H__

#include "execution/executor.hpp"
#include "common/murmurhash.hpp"
#include <unordered_set>

namespace wing {

    class DistinctExecutor : public Executor {
    public:
        DistinctExecutor (const OutputSchema& input_schema, 
                          std::unique_ptr<Executor> ch):
                          ch_(std::move(ch)) {
            for(size_t i = 0; i < input_schema.Size(); i++) {
                col_types_.push_back(input_schema[i].type_);
            }
        }
        
        void Init() override {
            ch_->Init();
        }
        
        InputTuplePtr Next() override {
            InputTuplePtr ch_ret;
            while((ch_ret = ch_->Next())) {
                const StaticFieldRef* ch_ret_col = reinterpret_cast<const StaticFieldRef*>(ch_ret.Data());
                size_t key = 0x114514;
                for(size_t i = 0; i < col_types_.size(); i++) {
                    if (col_types_[i] == FieldType::EMPTY) {
                        ch_ret_col++; 
                        continue;
                    }
                    key = get_hash_(ch_ret_col, col_types_[i], key);
                    ch_ret_col ++;
                }
                if (keys_.count(key)) {
                    continue;
                } else {
                    keys_.insert(key);
                    return ch_ret;
                }
            }
            return {};
        }
        
    private:
        std::unordered_set<size_t> keys_;
        std::unique_ptr<Executor> ch_;
        std::vector<FieldType> col_types_;

        size_t get_hash_(const StaticFieldRef* data_, FieldType type_, size_t seed_) {
            if (type_ == FieldType::VARCHAR || type_ == FieldType::CHAR) {
                return utils::Hash(StaticFieldRef::GetView(data_, FieldType::VARCHAR, 0), seed_);
            } else if (type_ == FieldType::INT32) {
                return utils::Hash(StaticFieldRef::GetView(data_, FieldType::INT32, 0), seed_);
            } 
            else {
                // type_ = FieldType::INT64 || RetType::FLOAT
                return utils::Hash(StaticFieldRef::GetView(data_, FieldType::INT64, sizeof(int64_t)), seed_);
            }
            // We ensure that `type_` != FieldType::EMPTY
        }
    };

}  // namespace wing

#endif