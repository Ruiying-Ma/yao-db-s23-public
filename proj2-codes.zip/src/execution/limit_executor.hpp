#ifndef SAKURA_LIMIT_EXECUTOR_H__
#define SAKURA_LIMIT_EXECUTOR_H__

#include "execution/executor.hpp"

namespace wing {

    class LimitExecutor : public Executor {
    public:
        LimitExecutor(const size_t& limit, const size_t& offset,
                      std::unique_ptr<Executor> ch): 
                      limit_(limit), offset_(offset), iter_(0),
                      ch_(std::move(ch)){};
                      
        void Init() override {
            ch_->Init();
        }
        
        InputTuplePtr Next() {
            while(iter_ < offset_) {
                if (ch_->Next()) {iter_++;}
                else {return {};}
            }
            if (iter_ >= (limit_ + offset_)) {
                return {};
            }
            // offset_ <= iter_ < offset_ + limit_
            iter_++;
            return ch_->Next();
        }
        
    private:
        size_t limit_, offset_;
        size_t iter_;
        std::unique_ptr<Executor> ch_;
    };
}  // namespace wing

#endif