#ifndef SAKURA_JOIN_EXECUTOR_H__
#define SAKURA_JOIN_EXECUTOR_H__

#include "execution/executor.hpp"

namespace wing {

class JoinExecutor : public Executor {
    public:
        JoinExecutor(const OutputSchema& left_input_schema, const OutputSchema& right_input_schema,
                     const std::unique_ptr<Expr>& predicate,
                     std::unique_ptr<Executor> left_ch, std::unique_ptr<Executor> right_ch):
                left_input_schema_(left_input_schema), right_input_schema_(right_input_schema),
                predicate_(predicate.get(), left_input_schema, right_input_schema),
                left_ch_(std::move(left_ch)), right_ch_(std::move(right_ch)),
                build_side_(left_input_schema){};

        void Init() override {
            left_ch_->Init();
            right_ch_->Init();
            // Build the left_ch: temporarily store all its tuples in TupleStore
            InputTuplePtr left_ch_ret;
            while((left_ch_ret = left_ch_->Next())) {
                build_side_.Append(left_ch_ret.Data()); // at this point, left_ch tuples are changed into `StaticFieldRef` form (by TupleVector)
            }
            build_side_ptrs_ = build_side_.GetPointerVec();
            build_side_iter_ = build_side_ptrs_.end();
            ret_.resize(left_input_schema_.Size() + right_input_schema_.Size());
        }

        InputTuplePtr Next() override {
            // Probe the right_ch: stop as soon as succeeding in finding a matching tuple in the build side
            while(true) {
                // If reach the end of the build side: select the next tuple in the probe side to match
                if (build_side_iter_ == build_side_ptrs_.end()) {
                    right_ch_ret_ = right_ch_->Next();
                    build_side_iter_ = build_side_ptrs_.begin();
                }
                // If reach the end of the probe side: return empty
                if (!right_ch_ret_) {return {};}
                // If this pair of tuples don't match: select the next tuple in the build side
                InputTuplePtr left_ch_ret(*build_side_iter_);
                if (predicate_ && predicate_.Evaluate(left_ch_ret, right_ch_ret_).ReadInt() == 0) {
                    build_side_iter_++;
                    continue;
                }
                // If this pair of tuples match (or predicate_ is empty): concatenate this pair of tuples and return
                size_t left_num_cols = left_input_schema_.Size();
                size_t right_num_cols = right_input_schema_.Size();
                // Copy left_ch_ret to ret (in bytes)
                std::memcpy(&ret_[0], *build_side_iter_, left_num_cols * sizeof(StaticFieldRef));
                // Copy right_ch_ret to ret
                if (right_input_schema_.IsRaw()) {
                    Tuple::DeSerialize((&ret_[0]) + left_num_cols, right_ch_ret_.Data(), right_input_schema_.GetCols());
                } else {
                    std::memcpy(&ret_[0] + left_num_cols, right_ch_ret_.Data(), right_num_cols * sizeof(StaticFieldRef));
                }
                build_side_iter_++;
                return ret_ ;
            }
        }
    private:
        OutputSchema left_input_schema_, right_input_schema_;
        JoinExprFunction predicate_;
        std::unique_ptr<Executor> left_ch_, right_ch_;
        TupleStore build_side_;
        std::vector<uint8_t*> build_side_ptrs_;
        std::vector<uint8_t*>::const_iterator build_side_iter_;
        InputTuplePtr right_ch_ret_;
        std::vector<StaticFieldRef> ret_;
    };

}  // namespace wing

#endif